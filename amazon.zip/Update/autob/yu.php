<?php
$ip = '198.240.100.14';
$data = [$ip];
$json = file_get_contents('file.json');
$data_old = json_decode($json, true);
$data_new = array_merge($data_old, $data);
$json = json_encode($data_new);
$result = file_put_contents('file.json', $json);